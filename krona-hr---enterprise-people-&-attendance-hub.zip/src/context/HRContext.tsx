import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Employee, 
  LeaveRequest, 
  AttendanceRecord, 
  PerformanceReview, 
  LiveActivityEvent,
  AttendanceStatus,
  LeaveType,
  DepartmentName,
  EmployeeGoal
} from '../types/hr';
import { 
  INITIAL_EMPLOYEES, 
  INITIAL_LEAVE_REQUESTS, 
  INITIAL_ATTENDANCE_LOGS, 
  INITIAL_PERFORMANCE_REVIEWS, 
  INITIAL_LIVE_EVENTS 
} from '../data/mockData';

interface HRContextType {
  employees: Employee[];
  attendanceLogs: AttendanceRecord[];
  leaveRequests: LeaveRequest[];
  performanceReviews: PerformanceReview[];
  liveEvents: LiveActivityEvent[];
  currentUser: Employee;
  currentTimeString: string;
  isRealtimeActive: boolean;
  setIsRealtimeActive: (active: boolean) => void;
  
  // Punch Clock & Attendance Actions
  clockIn: (employeeId?: string, location?: 'Office' | 'Remote') => void;
  clockOut: (employeeId?: string) => void;
  toggleBreak: (employeeId?: string) => void;
  addManualAttendance: (data: Omit<AttendanceRecord, 'id'>) => void;
  
  // Leave Management Actions
  approveLeave: (requestId: string, comment?: string) => void;
  rejectLeave: (requestId: string, comment?: string) => void;
  submitLeaveRequest: (data: {
    employeeId: string;
    leaveType: LeaveType;
    startDate: string;
    endDate: string;
    daysCount: number;
    reason: string;
    handoverTo?: string;
  }) => { success: boolean; message?: string };
  
  // Performance Actions
  submitPerformanceReview: (review: Omit<PerformanceReview, 'id' | 'submittedAt'>) => void;
  updateGoalProgress: (employeeId: string, goalId: string, newProgress: number) => void;
  addGoal: (employeeId: string, goal: Omit<EmployeeGoal, 'id'>) => void;
  
  // User & System
  switchCurrentUser: (employeeId: string) => void;
  resetAllData: () => void;
  selectedEmployeeForDrawer: Employee | null;
  setSelectedEmployeeForDrawer: (emp: Employee | null) => void;
}

const HRContext = createContext<HRContextType | undefined>(undefined);

const STORAGE_KEY_PREFIX = 'krona_hr_';

export const HRProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load from localStorage or defaults
  const [employees, setEmployees] = useState<Employee[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}employees`);
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return INITIAL_EMPLOYEES;
  });

  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}leaves`);
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return INITIAL_LEAVE_REQUESTS;
  });

  const [attendanceLogs, setAttendanceLogs] = useState<AttendanceRecord[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}attendance`);
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return INITIAL_ATTENDANCE_LOGS;
  });

  const [performanceReviews, setPerformanceReviews] = useState<PerformanceReview[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}reviews`);
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return INITIAL_PERFORMANCE_REVIEWS;
  });

  const [liveEvents, setLiveEvents] = useState<LiveActivityEvent[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}events`);
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return INITIAL_LIVE_EVENTS;
  });

  const [currentUserId, setCurrentUserId] = useState<string>('EMP-1001');
  const [selectedEmployeeForDrawer, setSelectedEmployeeForDrawer] = useState<Employee | null>(null);
  const [isRealtimeActive, setIsRealtimeActive] = useState<boolean>(true);
  const [currentTime, setCurrentTime] = useState<Date>(new Date());

  // Real-time ticking clock
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Save changes to localStorage
  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}employees`, JSON.stringify(employees));
  }, [employees]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}leaves`, JSON.stringify(leaveRequests));
  }, [leaveRequests]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}attendance`, JSON.stringify(attendanceLogs));
  }, [attendanceLogs]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}reviews`, JSON.stringify(performanceReviews));
  }, [performanceReviews]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}events`, JSON.stringify(liveEvents));
  }, [liveEvents]);

  // Simulated occasional real-time heartbeat event (every 35s if enabled)
  useEffect(() => {
    if (!isRealtimeActive) return;
    const interval = setInterval(() => {
      // Pick random simulated event
      const simulationOptions = [
        {
          type: 'check_in' as const,
          name: 'Mei-Ling Chen',
          dept: 'Engineering' as DepartmentName,
          desc: 'Synchronized remote workstation pulse from Toronto node'
        },
        {
          type: 'break_start' as const,
          name: 'Marcus Vance',
          dept: 'Engineering' as DepartmentName,
          desc: 'Paused timer for technical architecture peer sync'
        },
        {
          type: 'check_out' as const,
          name: 'Julian Navarro',
          dept: 'Sales' as DepartmentName,
          desc: 'Clocked out for offsite client presentation'
        }
      ];
      const pick = simulationOptions[Math.floor(Math.random() * simulationOptions.length)];
      const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      
      const newEvt: LiveActivityEvent = {
        id: `evt-${Date.now()}`,
        timestamp: nowStr,
        type: pick.type,
        employeeName: pick.name,
        department: pick.dept,
        description: pick.desc
      };

      setLiveEvents(prev => [newEvt, ...prev.slice(0, 19)]);
    }, 35000);

    return () => clearInterval(interval);
  }, [isRealtimeActive]);

  const currentUser = employees.find(e => e.id === currentUserId) || employees[0];

  const formatNowTime = () => {
    return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const getTodayDateStr = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };

  // Clock In
  const clockIn = (employeeId?: string, location: 'Office' | 'Remote' = 'Office') => {
    const targetId = employeeId || currentUser.id;
    const timeStr = formatNowTime();
    const todayStr = getTodayDateStr();

    setEmployees(prev => prev.map(emp => {
      if (emp.id === targetId) {
        return {
          ...emp,
          todayStatus: location === 'Remote' ? 'remote' : 'present',
          checkInTime: timeStr,
          checkOutTime: undefined,
          breakStartTime: undefined,
          totalHoursToday: emp.totalHoursToday > 0 ? emp.totalHoursToday : 0.1
        };
      }
      return emp;
    }));

    const empObj = employees.find(e => e.id === targetId);
    const empName = empObj ? empObj.name : 'Employee';
    const dept = empObj ? empObj.department : 'Engineering';

    // Add to attendance log
    const newRecord: AttendanceRecord = {
      id: `ATT-${Date.now()}`,
      employeeId: targetId,
      employeeName: empName,
      department: dept,
      date: todayStr,
      checkIn: timeStr,
      workDurationHours: 0.1,
      overtimeHours: 0,
      status: location === 'Remote' ? 'remote' : 'present',
      location,
      ipOrDevice: location === 'Remote' ? 'Secure Gateway VPN' : 'HQ Internal Access Hub',
    };

    setAttendanceLogs(prev => [newRecord, ...prev]);

    // Add live event
    const newEvent: LiveActivityEvent = {
      id: `evt-${Date.now()}`,
      timestamp: timeStr,
      type: 'check_in',
      employeeName: empName,
      department: dept,
      description: `Clocked in (${location}) via real-time portal`,
    };
    setLiveEvents(prev => [newEvent, ...prev.slice(0, 19)]);
  };

  // Clock Out
  const clockOut = (employeeId?: string) => {
    const targetId = employeeId || currentUser.id;
    const timeStr = formatNowTime();

    let empName = '';
    let dept: DepartmentName = 'Engineering';

    setEmployees(prev => prev.map(emp => {
      if (emp.id === targetId) {
        empName = emp.name;
        dept = emp.department;
        return {
          ...emp,
          todayStatus: 'present',
          checkOutTime: timeStr,
          breakStartTime: undefined
        };
      }
      return emp;
    }));

    // Update existing attendance log
    const todayStr = getTodayDateStr();
    setAttendanceLogs(prev => prev.map(rec => {
      if (rec.employeeId === targetId && rec.date === todayStr && !rec.checkOut) {
        return {
          ...rec,
          checkOut: timeStr
        };
      }
      return rec;
    }));

    // Add live event
    const newEvent: LiveActivityEvent = {
      id: `evt-${Date.now()}`,
      timestamp: timeStr,
      type: 'check_out',
      employeeName: empName || 'Employee',
      department: dept,
      description: `Clocked out for the workday at ${timeStr}`,
    };
    setLiveEvents(prev => [newEvent, ...prev.slice(0, 19)]);
  };

  // Toggle Break
  const toggleBreak = (employeeId?: string) => {
    const targetId = employeeId || currentUser.id;
    const timeStr = formatNowTime();
    let isStarting = false;
    let empName = '';
    let dept: DepartmentName = 'Engineering';

    setEmployees(prev => prev.map(emp => {
      if (emp.id === targetId) {
        empName = emp.name;
        dept = emp.department;
        const currentBreak = emp.todayStatus === 'on_break';
        isStarting = !currentBreak;
        return {
          ...emp,
          todayStatus: isStarting ? 'on_break' : 'present',
          breakStartTime: isStarting ? timeStr : undefined
        };
      }
      return emp;
    }));

    const newEvent: LiveActivityEvent = {
      id: `evt-${Date.now()}`,
      timestamp: timeStr,
      type: isStarting ? 'break_start' : 'check_in',
      employeeName: empName || 'Employee',
      department: dept,
      description: isStarting ? `Initiated scheduled rest break` : `Returned from break, resumed active shift`,
    };
    setLiveEvents(prev => [newEvent, ...prev.slice(0, 19)]);
  };

  // Add Manual Attendance record
  const addManualAttendance = (data: Omit<AttendanceRecord, 'id'>) => {
    const newId = `ATT-${Date.now()}`;
    const newRec: AttendanceRecord = {
      ...data,
      id: newId
    };
    setAttendanceLogs(prev => [newRec, ...prev]);

    // Also update employee status if date is today
    const todayStr = getTodayDateStr();
    if (data.date === todayStr) {
      setEmployees(prev => prev.map(emp => {
        if (emp.id === data.employeeId) {
          return {
            ...emp,
            todayStatus: data.status,
            checkInTime: data.checkIn,
            checkOutTime: data.checkOut,
            totalHoursToday: data.workDurationHours
          };
        }
        return emp;
      }));
    }
  };

  // Approve Leave Request
  const approveLeave = (requestId: string, comment?: string) => {
    let reqEmpName = '';
    let reqDept: DepartmentName = 'Engineering';
    let reqType: LeaveType = 'annual';
    let days = 1;
    let empId = '';

    setLeaveRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        reqEmpName = req.employeeName;
        reqDept = req.department;
        reqType = req.leaveType;
        days = req.daysCount;
        empId = req.employeeId;
        return {
          ...req,
          status: 'approved',
          reviewedBy: currentUser.name,
          reviewedAt: `${getTodayDateStr()} ${formatNowTime()}`,
          reviewComment: comment || 'Leave request approved by HR manager.'
        };
      }
      return req;
    }));

    // Deduct from employee balance
    if (empId && (reqType === 'annual' || reqType === 'sick' || reqType === 'casual')) {
      const trackedKey = reqType as 'annual' | 'sick' | 'casual';
      setEmployees(prev => prev.map(emp => {
        if (emp.id === empId) {
          const currentBal = emp.leaveBalances[trackedKey];
          return {
            ...emp,
            leaveBalances: {
              ...emp.leaveBalances,
              [trackedKey]: {
                ...currentBal,
                used: currentBal.used + days
              }
            }
          };
        }
        return emp;
      }));
    }

    const newEvent: LiveActivityEvent = {
      id: `evt-${Date.now()}`,
      timestamp: formatNowTime(),
      type: 'leave_approved',
      employeeName: reqEmpName,
      department: reqDept,
      description: `Leave request (${days} days ${reqType}) approved by ${currentUser.name}`,
    };
    setLiveEvents(prev => [newEvent, ...prev.slice(0, 19)]);
  };

  // Reject Leave Request
  const rejectLeave = (requestId: string, comment?: string) => {
    let reqEmpName = '';
    let reqDept: DepartmentName = 'Engineering';

    setLeaveRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        reqEmpName = req.employeeName;
        reqDept = req.department;
        return {
          ...req,
          status: 'rejected',
          reviewedBy: currentUser.name,
          reviewedAt: `${getTodayDateStr()} ${formatNowTime()}`,
          reviewComment: comment || 'Leave request declined due to staffing coverage requirements.'
        };
      }
      return req;
    }));

    const newEvent: LiveActivityEvent = {
      id: `evt-${Date.now()}`,
      timestamp: formatNowTime(),
      type: 'leave_rejected',
      employeeName: reqEmpName,
      department: reqDept,
      description: `Leave request declined with feedback notes`,
    };
    setLiveEvents(prev => [newEvent, ...prev.slice(0, 19)]);
  };

  // Submit Leave Request
  const submitLeaveRequest = (data: {
    employeeId: string;
    leaveType: LeaveType;
    startDate: string;
    endDate: string;
    daysCount: number;
    reason: string;
    handoverTo?: string;
  }) => {
    const targetEmp = employees.find(e => e.id === data.employeeId);
    if (!targetEmp) return { success: false, message: 'Employee not found.' };

    // Check balances for tracked types
    if (data.leaveType === 'annual' || data.leaveType === 'sick' || data.leaveType === 'casual') {
      const bal = targetEmp.leaveBalances[data.leaveType];
      const remaining = bal.total - bal.used;
      if (data.daysCount > remaining) {
        return { 
          success: false, 
          message: `Insufficient ${data.leaveType} leave balance. Available: ${remaining} days, requested: ${data.daysCount} days.` 
        };
      }
    }

    const newReq: LeaveRequest = {
      id: `LR-${Math.floor(1000 + Math.random() * 9000)}`,
      employeeId: data.employeeId,
      employeeName: targetEmp.name,
      employeeAvatar: targetEmp.avatarUrl,
      department: targetEmp.department,
      leaveType: data.leaveType,
      startDate: data.startDate,
      endDate: data.endDate,
      daysCount: data.daysCount,
      reason: data.reason,
      appliedOn: getTodayDateStr(),
      status: 'pending',
      handoverTo: data.handoverTo,
    };

    setLeaveRequests(prev => [newReq, ...prev]);

    const newEvent: LiveActivityEvent = {
      id: `evt-${Date.now()}`,
      timestamp: formatNowTime(),
      type: 'leave_requested',
      employeeName: targetEmp.name,
      department: targetEmp.department,
      description: `Submitted ${data.daysCount}-day ${data.leaveType} leave request for review`,
    };
    setLiveEvents(prev => [newEvent, ...prev.slice(0, 19)]);

    return { success: true };
  };

  // Submit Performance Review
  const submitPerformanceReview = (review: Omit<PerformanceReview, 'id' | 'submittedAt'>) => {
    const newRev: PerformanceReview = {
      ...review,
      id: `REV-${Date.now()}`,
      submittedAt: getTodayDateStr(),
    };
    setPerformanceReviews(prev => [newRev, ...prev]);

    // Update employee performance score
    setEmployees(prev => prev.map(emp => {
      if (emp.id === review.employeeId) {
        return {
          ...emp,
          performanceScore: Number(review.ratingOverall.toFixed(1))
        };
      }
      return emp;
    }));

    const newEvent: LiveActivityEvent = {
      id: `evt-${Date.now()}`,
      timestamp: formatNowTime(),
      type: 'review_submitted',
      employeeName: review.employeeName,
      department: employees.find(e => e.id === review.employeeId)?.department || 'Engineering',
      description: `Formal review submitted by ${review.reviewerName} (Score: ${review.ratingOverall}/5.0)`,
    };
    setLiveEvents(prev => [newEvent, ...prev.slice(0, 19)]);
  };

  // Update Goal Progress
  const updateGoalProgress = (employeeId: string, goalId: string, newProgress: number) => {
    const clamped = Math.min(100, Math.max(0, newProgress));
    const newStatus = clamped === 100 ? 'completed' : clamped < 40 ? 'at_risk' : 'on_track';

    setEmployees(prev => prev.map(emp => {
      if (emp.id === employeeId) {
        return {
          ...emp,
          keyGoals: emp.keyGoals.map(g => {
            if (g.id === goalId) {
              return {
                ...g,
                progressPercent: clamped,
                status: newStatus
              };
            }
            return g;
          })
        };
      }
      return emp;
    }));
  };

  // Add Goal
  const addGoal = (employeeId: string, goal: Omit<EmployeeGoal, 'id'>) => {
    const newG: EmployeeGoal = {
      ...goal,
      id: `g-${Date.now()}`
    };
    setEmployees(prev => prev.map(emp => {
      if (emp.id === employeeId) {
        return {
          ...emp,
          keyGoals: [...emp.keyGoals, newG]
        };
      }
      return emp;
    }));
  };

  // Switch current user persona
  const switchCurrentUser = (employeeId: string) => {
    setCurrentUserId(employeeId);
  };

  // Reset all to sample defaults
  const resetAllData = () => {
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}employees`);
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}leaves`);
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}attendance`);
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}reviews`);
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}events`);
    setEmployees(INITIAL_EMPLOYEES);
    setLeaveRequests(INITIAL_LEAVE_REQUESTS);
    setAttendanceLogs(INITIAL_ATTENDANCE_LOGS);
    setPerformanceReviews(INITIAL_PERFORMANCE_REVIEWS);
    setLiveEvents(INITIAL_LIVE_EVENTS);
    setCurrentUserId('EMP-1001');
    setSelectedEmployeeForDrawer(null);
  };

  const currentTimeString = currentTime.toLocaleTimeString([], { 
    hour: '2-digit', 
    minute: '2-digit', 
    second: '2-digit' 
  });

  return (
    <HRContext.Provider
      value={{
        employees,
        attendanceLogs,
        leaveRequests,
        performanceReviews,
        liveEvents,
        currentUser,
        currentTimeString,
        isRealtimeActive,
        setIsRealtimeActive,
        clockIn,
        clockOut,
        toggleBreak,
        addManualAttendance,
        approveLeave,
        rejectLeave,
        submitLeaveRequest,
        submitPerformanceReview,
        updateGoalProgress,
        addGoal,
        switchCurrentUser,
        resetAllData,
        selectedEmployeeForDrawer,
        setSelectedEmployeeForDrawer,
      }}
    >
      {children}
    </HRContext.Provider>
  );
};

export const useHR = () => {
  const context = useContext(HRContext);
  if (!context) {
    throw new Error('useHR must be used within an HRProvider');
  }
  return context;
};
