export type AttendanceStatus = 'present' | 'remote' | 'on_break' | 'late' | 'absent' | 'on_leave';

export type LeaveType = 'annual' | 'sick' | 'casual' | 'parental' | 'unpaid' | 'bereavement';

export type LeaveStatus = 'pending' | 'approved' | 'rejected' | 'cancelled';

export type DepartmentName = 
  | 'Engineering' 
  | 'Product' 
  | 'Design' 
  | 'Marketing' 
  | 'Sales' 
  | 'Operations' 
  | 'People & HR';

export interface Employee {
  id: string;
  name: string;
  email: string;
  role: string;
  department: DepartmentName;
  avatarUrl: string;
  joinedDate: string;
  phone: string;
  location: string; // e.g. "HQ Office, Floor 4" or "Remote - Berlin"
  managerName: string;
  salaryTier: string;
  todayStatus: AttendanceStatus;
  checkInTime?: string;
  checkOutTime?: string;
  breakStartTime?: string;
  totalHoursToday: number; // e.g. 7.5
  weeklyHoursLogged: number; // e.g. 38.2
  attendanceRateMonth: number; // e.g. 98.2%
  performanceScore: number; // out of 5.0 (e.g. 4.7)
  leaveBalances: {
    annual: { used: number; total: number };
    sick: { used: number; total: number };
    casual: { used: number; total: number };
  };
  keyGoals: EmployeeGoal[];
}

export interface EmployeeGoal {
  id: string;
  title: string;
  targetDate: string;
  progressPercent: number;
  status: 'on_track' | 'at_risk' | 'completed';
  category: 'Strategic' | 'Delivery' | 'Culture' | 'Technical';
}

export interface AttendanceRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  department: DepartmentName;
  date: string; // YYYY-MM-DD
  checkIn: string; // e.g. "08:55 AM"
  checkOut?: string; // e.g. "05:15 PM"
  workDurationHours: number;
  overtimeHours: number;
  status: AttendanceStatus;
  location: 'Office' | 'Remote' | 'Client Site';
  ipOrDevice: string;
}

export interface LeaveRequest {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeAvatar: string;
  department: DepartmentName;
  leaveType: LeaveType;
  startDate: string;
  endDate: string;
  daysCount: number;
  reason: string;
  appliedOn: string;
  status: LeaveStatus;
  handoverTo?: string;
  reviewedBy?: string;
  reviewedAt?: string;
  reviewComment?: string;
}

export interface PerformanceReview {
  id: string;
  employeeId: string;
  employeeName: string;
  reviewerName: string;
  reviewPeriod: string; // e.g. "Q3 2026"
  ratingOverall: number; // 1.0 - 5.0
  competencies: {
    leadership: number;
    jobKnowledge: number;
    teamCollaboration: number;
    deliverySpeed: number;
    initiative: number;
  };
  achievements: string;
  areasToGrow: string;
  submittedAt: string;
}

export interface LiveActivityEvent {
  id: string;
  timestamp: string;
  type: 'check_in' | 'check_out' | 'leave_requested' | 'leave_approved' | 'leave_rejected' | 'review_submitted' | 'break_start';
  employeeName: string;
  department: DepartmentName;
  description: string;
}
