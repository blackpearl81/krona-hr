import React from 'react';
import { 
  X, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar, 
  Star, 
  Clock, 
  Briefcase, 
  Award, 
  CheckCircle, 
  ShieldCheck, 
  Coffee, 
  LogOut, 
  Building, 
  Plus,
  TrendingUp
} from 'lucide-react';
import { useHR } from '../../context/HRContext';
import { Employee } from '../../types/hr';

interface EmployeeDetailDrawerProps {
  employee: Employee | null;
  onClose: () => void;
  onOpenLeaveModalForEmployee: (empId: string) => void;
}

export const EmployeeDetailDrawer: React.FC<EmployeeDetailDrawerProps> = ({
  employee,
  onClose,
  onOpenLeaveModalForEmployee,
}) => {
  const { clockIn, clockOut, toggleBreak, performanceReviews } = useHR();

  if (!employee) return null;

  const employeeReviews = performanceReviews.filter(r => r.employeeId === employee.id);
  const isClockedIn = employee.todayStatus === 'present' || employee.todayStatus === 'remote';
  const isOnBreak = employee.todayStatus === 'on_break';

  const annualLeft = employee.leaveBalances.annual.total - employee.leaveBalances.annual.used;
  const sickLeft = employee.leaveBalances.sick.total - employee.leaveBalances.sick.used;
  const casualLeft = employee.leaveBalances.casual.total - employee.leaveBalances.casual.used;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/50 backdrop-blur-xs flex justify-end">
      <div className="w-full max-w-xl bg-white h-full shadow-2xl flex flex-col border-l border-slate-200">
        {/* Drawer Header */}
        <div className="p-6 border-b border-slate-200 flex items-start justify-between bg-slate-50">
          <div className="flex items-start gap-4">
            {employee.avatarUrl ? (
              <img
                src={employee.avatarUrl}
                alt={employee.name}
                referrerPolicy="no-referrer"
                className="w-16 h-16 rounded-full object-cover ring-2 ring-white shadow-sm shrink-0"
              />
            ) : (
              <div className="w-16 h-16 rounded-full bg-slate-200 text-slate-800 flex items-center justify-center font-bold text-lg shrink-0">
                {employee.name.split(' ').map(n => n[0]).join('')}
              </div>
            )}
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-900">
                  {employee.name}
                </h2>
                <span className="text-xs font-mono text-slate-400">
                  {employee.id}
                </span>
              </div>
              <p className="text-xs font-medium text-slate-700 mt-0.5">
                {employee.role}
              </p>
              <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                <span>{employee.department}</span>
                <span>·</span>
                <span>Reports to {employee.managerName}</span>
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-md transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Dossier Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
          {/* Today's Live Shift Card & Fast Controls */}
          <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-900">
                Today's Shift Status
              </span>
              <span className={`font-semibold capitalize ${
                employee.todayStatus === 'present' ? 'text-emerald-700' :
                employee.todayStatus === 'remote' ? 'text-indigo-700' :
                employee.todayStatus === 'on_break' ? 'text-amber-700' :
                employee.todayStatus === 'late' ? 'text-orange-700' :
                employee.todayStatus === 'on_leave' ? 'text-blue-700' : 'text-rose-700'
              }`}>
                {employee.todayStatus.replace('_', ' ')}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 text-[11px] py-1 border-y border-slate-200">
              <div>
                <span className="text-slate-500 block">Check-In</span>
                <span className="font-mono font-bold text-slate-900 tabular-nums">
                  {employee.checkInTime || '—'}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Hours Today</span>
                <span className="font-mono font-bold text-slate-900 tabular-nums">
                  {employee.totalHoursToday.toFixed(1)} h
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Monthly Rate</span>
                <span className="font-mono font-bold text-emerald-700 tabular-nums">
                  {employee.attendanceRateMonth}%
                </span>
              </div>
            </div>

            {/* Manager quick override actions */}
            <div className="flex items-center gap-2 pt-1">
              {!isClockedIn ? (
                <button
                  onClick={() => clockIn(employee.id, 'Office')}
                  className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-semibold text-xs flex items-center justify-center gap-1.5"
                >
                  <Building className="w-3.5 h-3.5" />
                  <span>Clock In Staff Member</span>
                </button>
              ) : (
                <>
                  <button
                    onClick={() => toggleBreak(employee.id)}
                    className="flex-1 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 rounded font-semibold text-xs flex items-center justify-center gap-1.5"
                  >
                    <Coffee className="w-3.5 h-3.5 text-amber-600" />
                    <span>{isOnBreak ? 'Resume Work' : 'Record Break'}</span>
                  </button>
                  <button
                    onClick={() => clockOut(employee.id)}
                    className="flex-1 py-1.5 bg-slate-900 hover:bg-rose-700 text-white rounded font-semibold text-xs flex items-center justify-center gap-1.5"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Clock Out</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Contact & Employment Meta */}
          <div className="space-y-2">
            <h3 className="font-semibold text-slate-900 uppercase tracking-wider text-[11px]">
              Employment Profile
            </h3>
            <div className="grid grid-cols-2 gap-3 p-3 bg-white border border-slate-200 rounded-lg text-slate-700">
              <div>
                <span className="text-slate-500 block text-[11px]">Work Email</span>
                <span className="font-mono text-[11px] font-medium text-slate-900">{employee.email}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px]">Phone</span>
                <span className="font-mono text-[11px] font-medium text-slate-900">{employee.phone}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px]">Office Location</span>
                <span className="font-medium text-slate-900">{employee.location}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px]">Compensation Band</span>
                <span className="font-medium text-slate-900">{employee.salaryTier}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px]">Date Joined</span>
                <span className="font-mono text-[11px] text-slate-900">{employee.joinedDate}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px]">Weekly Cumulative Hours</span>
                <span className="font-mono text-[11px] font-bold text-slate-900 tabular-nums">{employee.weeklyHoursLogged} hrs</span>
              </div>
            </div>
          </div>

          {/* Leave Quota Balances */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-slate-900 uppercase tracking-wider text-[11px]">
                Paid Leave Quotas & Balances
              </h3>
              <button
                onClick={() => {
                  onClose();
                  onOpenLeaveModalForEmployee(employee.id);
                }}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
              >
                <Plus className="w-3 h-3" />
                <span>Apply PTO</span>
              </button>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded text-center">
                <span className="text-slate-500 text-[11px] block">Annual Vacation</span>
                <span className="text-lg font-mono font-bold text-slate-900 tabular-nums block mt-1">
                  {annualLeft}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">
                  of {employee.leaveBalances.annual.total} days left
                </span>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded text-center">
                <span className="text-slate-500 text-[11px] block">Medical / Sick</span>
                <span className="text-lg font-mono font-bold text-slate-900 tabular-nums block mt-1">
                  {sickLeft}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">
                  of {employee.leaveBalances.sick.total} days left
                </span>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded text-center">
                <span className="text-slate-500 text-[11px] block">Casual Leave</span>
                <span className="text-lg font-mono font-bold text-slate-900 tabular-nums block mt-1">
                  {casualLeft}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">
                  of {employee.leaveBalances.casual.total} days left
                </span>
              </div>
            </div>
          </div>

          {/* Quarterly OKRs & Key Goals */}
          <div className="space-y-2">
            <h3 className="font-semibold text-slate-900 uppercase tracking-wider text-[11px]">
              Assigned Performance OKRs
            </h3>
            <div className="space-y-2">
              {employee.keyGoals.map(g => (
                <div key={g.id} className="p-3 bg-white border border-slate-200 rounded space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-900">{g.title}</span>
                    <span className="font-mono text-slate-600 font-bold tabular-nums">
                      {g.progressPercent}%
                    </span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        g.progressPercent === 100 ? 'bg-emerald-500' :
                        g.status === 'at_risk' ? 'bg-amber-500' : 'bg-indigo-600'
                      }`}
                      style={{ width: `${g.progressPercent}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-0.5">
                    <span>Due: {g.targetDate}</span>
                    <span className="capitalize">{g.category}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 360 Appraisal History */}
          {employeeReviews.length > 0 && (
            <div className="space-y-2">
              <h3 className="font-semibold text-slate-900 uppercase tracking-wider text-[11px]">
                Appraisal Record
              </h3>
              {employeeReviews.map(r => (
                <div key={r.id} className="p-3 bg-slate-50 border border-slate-200 rounded space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">{r.reviewPeriod} Evaluation</span>
                    <span className="font-mono font-bold text-indigo-700">{r.ratingOverall}/5.0</span>
                  </div>
                  <p className="text-slate-700">
                    <strong>Wins:</strong> {r.achievements}
                  </p>
                  <p className="text-slate-600 italic">
                    <strong>Growth:</strong> {r.areasToGrow}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
