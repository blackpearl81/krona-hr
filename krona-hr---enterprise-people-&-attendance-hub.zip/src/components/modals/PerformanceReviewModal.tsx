import React, { useState } from 'react';
import { X, Star, Award, CheckCircle2 } from 'lucide-react';
import { useHR } from '../../context/HRContext';

interface PerformanceReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PerformanceReviewModal: React.FC<PerformanceReviewModalProps> = ({ isOpen, onClose }) => {
  const { employees, currentUser, submitPerformanceReview } = useHR();

  const [employeeId, setEmployeeId] = useState<string>(employees[1]?.id || employees[0]?.id || '');
  const [reviewPeriod, setReviewPeriod] = useState<string>('Q3 2026');
  const [leadership, setLeadership] = useState<number>(4.8);
  const [jobKnowledge, setJobKnowledge] = useState<number>(4.9);
  const [teamCollaboration, setTeamCollaboration] = useState<number>(4.7);
  const [deliverySpeed, setDeliverySpeed] = useState<number>(4.6);
  const [initiative, setInitiative] = useState<number>(4.8);
  const [achievements, setAchievements] = useState<string>('');
  const [areasToGrow, setAreasToGrow] = useState<string>('');
  const [success, setSuccess] = useState<boolean>(false);

  if (!isOpen) return null;

  const targetEmp = employees.find(e => e.id === employeeId) || employees[0];

  const overallScore = Number(
    ((leadership + jobKnowledge + teamCollaboration + deliverySpeed + initiative) / 5).toFixed(1)
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    submitPerformanceReview({
      employeeId: targetEmp.id,
      employeeName: targetEmp.name,
      reviewerName: currentUser.name,
      reviewPeriod,
      ratingOverall: overallScore,
      competencies: {
        leadership,
        jobKnowledge,
        teamCollaboration,
        deliverySpeed,
        initiative,
      },
      achievements: achievements.trim() || 'Demonstrated outstanding dedication and leadership in team initiatives.',
      areasToGrow: areasToGrow.trim() || 'Continue scaling delegation to support upcoming company expansion.',
    });

    setSuccess(true);
    setTimeout(() => {
      setSuccess(false);
      onClose();
    }, 900);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-lg w-full p-6 space-y-4 my-8">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div>
            <h2 className="text-sm font-bold text-slate-900">
              Submit Formal 360° Performance Appraisal
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Calibrated competency evaluation for talent review
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 transition-colors p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {success && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded text-xs text-emerald-800 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Appraisal published and employee score updated!</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Employee & Period */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Candidate Under Review
              </label>
              <select
                value={employeeId}
                onChange={(e) => setEmployeeId(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
              >
                {employees.map(emp => (
                  <option key={emp.id} value={emp.id}>
                    {emp.name} ({emp.department})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Evaluation Period
              </label>
              <input
                type="text"
                value={reviewPeriod}
                onChange={(e) => setReviewPeriod(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
              />
            </div>
          </div>

          {/* Overall Rating Banner */}
          <div className="p-3 bg-indigo-50 border border-indigo-100 rounded flex items-center justify-between">
            <span className="font-semibold text-indigo-950">
              Computed Overall Appraisal Score
            </span>
            <span className="text-base font-bold font-mono text-indigo-700 tabular-nums">
              {overallScore} / 5.0
            </span>
          </div>

          {/* Competency Sliders */}
          <div className="space-y-3 pt-1">
            <div className="space-y-1">
              <div className="flex justify-between text-slate-700">
                <span>Strategic Leadership & Impact</span>
                <span className="font-mono font-bold text-slate-900">{leadership}</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="5.0"
                step="0.1"
                value={leadership}
                onChange={(e) => setLeadership(parseFloat(e.target.value))}
                className="w-full accent-indigo-600"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-slate-700">
                <span>Job Knowledge & Domain Excellence</span>
                <span className="font-mono font-bold text-slate-900">{jobKnowledge}</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="5.0"
                step="0.1"
                value={jobKnowledge}
                onChange={(e) => setJobKnowledge(parseFloat(e.target.value))}
                className="w-full accent-indigo-600"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-slate-700">
                <span>Cross-Functional Team Collaboration</span>
                <span className="font-mono font-bold text-slate-900">{teamCollaboration}</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="5.0"
                step="0.1"
                value={teamCollaboration}
                onChange={(e) => setTeamCollaboration(parseFloat(e.target.value))}
                className="w-full accent-indigo-600"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-slate-700">
                <span>Execution Cadence & Delivery Speed</span>
                <span className="font-mono font-bold text-slate-900">{deliverySpeed}</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="5.0"
                step="0.1"
                value={deliverySpeed}
                onChange={(e) => setDeliverySpeed(parseFloat(e.target.value))}
                className="w-full accent-indigo-600"
              />
            </div>
          </div>

          {/* Qualitative Feedback */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Key Wins & Noteworthy Achievements
            </label>
            <textarea
              rows={2}
              placeholder="Highlight major project milestones, leadership actions, or team contributions..."
              value={achievements}
              onChange={(e) => setAchievements(e.target.value)}
              className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
              required
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Development Areas & Opportunities to Grow
            </label>
            <textarea
              rows={2}
              placeholder="Constructive feedback, technical certifications, or managerial scaling areas..."
              value={areasToGrow}
              onChange={(e) => setAreasToGrow(e.target.value)}
              className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
              required
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded shadow-xs"
            >
              Submit Appraisal
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
