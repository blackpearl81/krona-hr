import React, { useState } from 'react';
import { X, Clock, CheckCircle2, AlertCircle } from 'lucide-react';
import { useHR } from '../../context/HRContext';
import { AttendanceStatus, DepartmentName } from '../../types/hr';

interface ManualAttendanceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ManualAttendanceModal: React.FC<ManualAttendanceModalProps> = ({ isOpen, onClose }) => {
  const { employees, addManualAttendance } = useHR();

  const [employeeId, setEmployeeId] = useState<string>(employees[0]?.id || '');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [checkInTime, setCheckInTime] = useState<string>('09:00 AM');
  const [checkOutTime, setCheckOutTime] = useState<string>('05:30 PM');
  const [workHours, setWorkHours] = useState<number>(8.0);
  const [status, setStatus] = useState<AttendanceStatus>('present');
  const [locationType, setLocationType] = useState<'Office' | 'Remote' | 'Client Site'>('Office');
  const [reasonNote, setReasonNote] = useState<string>('Manual timesheet logging verified by HR Ops');

  if (!isOpen) return null;

  const targetEmp = employees.find(e => e.id === employeeId) || employees[0];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    addManualAttendance({
      employeeId: targetEmp.id,
      employeeName: targetEmp.name,
      department: targetEmp.department,
      date,
      checkIn: checkInTime,
      checkOut: checkOutTime,
      workDurationHours: Number(workHours),
      overtimeHours: Math.max(0, Number(workHours) - 8.0),
      status,
      location: locationType,
      ipOrDevice: `Manual Entry: ${reasonNote}`,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-md w-full p-6 space-y-4 my-8">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div>
            <h2 className="text-sm font-bold text-slate-900">
              Manual Attendance Entry
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Record retroactive punch adjustments or onsite visits
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 transition-colors p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Employee Selection */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Employee
            </label>
            <select
              value={employeeId}
              onChange={(e) => setEmployeeId(e.target.value)}
              className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
            >
              {employees.map(emp => (
                <option key={emp.id} value={emp.id}>
                  {emp.name} — {emp.role} ({emp.department})
                </option>
              ))}
            </select>
          </div>

          {/* Date & Location */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Date
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                required
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Location
              </label>
              <select
                value={locationType}
                onChange={(e) => setLocationType(e.target.value as any)}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
              >
                <option value="Office">HQ Office</option>
                <option value="Remote">Remote</option>
                <option value="Client Site">Client Site</option>
              </select>
            </div>
          </div>

          {/* Times */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Check In Time
              </label>
              <input
                type="text"
                placeholder="09:00 AM"
                value={checkInTime}
                onChange={(e) => setCheckInTime(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                required
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Check Out Time
              </label>
              <input
                type="text"
                placeholder="05:30 PM"
                value={checkOutTime}
                onChange={(e) => setCheckOutTime(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
              />
            </div>
          </div>

          {/* Hours & Status */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Duration (Hours)
              </label>
              <input
                type="number"
                step="0.5"
                min="0"
                max="24"
                value={workHours}
                onChange={(e) => setWorkHours(parseFloat(e.target.value) || 0)}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                required
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Attendance Status
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as AttendanceStatus)}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
              >
                <option value="present">Present (Normal)</option>
                <option value="remote">Present (Remote)</option>
                <option value="late">Late Arrival</option>
                <option value="on_break">On Break</option>
              </select>
            </div>
          </div>

          {/* Audit Note */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Adjustment Reason
            </label>
            <input
              type="text"
              placeholder="e.g. Badge sensor glitch or client site meeting"
              value={reasonNote}
              onChange={(e) => setReasonNote(e.target.value)}
              className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded shadow-xs"
            >
              Save Attendance Record
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
