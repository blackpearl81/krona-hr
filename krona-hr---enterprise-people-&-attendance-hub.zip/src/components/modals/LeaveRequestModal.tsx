import React, { useState } from 'react';
import { X, Calendar, AlertCircle, CheckCircle2 } from 'lucide-react';
import { useHR } from '../../context/HRContext';
import { LeaveType } from '../../types/hr';

interface LeaveRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LeaveRequestModal: React.FC<LeaveRequestModalProps> = ({ isOpen, onClose }) => {
  const { employees, currentUser, submitLeaveRequest } = useHR();

  const [employeeId, setEmployeeId] = useState<string>(currentUser.id);
  const [leaveType, setLeaveType] = useState<LeaveType>('annual');
  const [startDate, setStartDate] = useState<string>('2026-10-15');
  const [endDate, setEndDate] = useState<string>('2026-10-16');
  const [reason, setReason] = useState<string>('');
  const [handoverTo, setHandoverTo] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [successMessage, setSuccessMessage] = useState<string>('');

  if (!isOpen) return null;

  const targetEmp = employees.find(e => e.id === employeeId) || currentUser;

  // Calculate business days
  const calculateDays = () => {
    if (!startDate || !endDate) return 1;
    const start = new Date(startDate);
    const end = new Date(endDate);
    if (end < start) return 0;
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
    return diffDays;
  };

  const daysCount = calculateDays();

  // Balance calculation
  const getAvailableBalance = () => {
    if (leaveType === 'annual') {
      return targetEmp.leaveBalances.annual.total - targetEmp.leaveBalances.annual.used;
    }
    if (leaveType === 'sick') {
      return targetEmp.leaveBalances.sick.total - targetEmp.leaveBalances.sick.used;
    }
    if (leaveType === 'casual') {
      return targetEmp.leaveBalances.casual.total - targetEmp.leaveBalances.casual.used;
    }
    return 30; // Parental / Unpaid
  };

  const availableBalance = getAvailableBalance();
  const isOverQuota = daysCount > availableBalance;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (daysCount <= 0) {
      setErrorMessage('End date cannot precede start date.');
      return;
    }

    if (!reason.trim()) {
      setErrorMessage('Please state the business or personal reason for this leave request.');
      return;
    }

    const result = submitLeaveRequest({
      employeeId,
      leaveType,
      startDate,
      endDate,
      daysCount,
      reason,
      handoverTo: handoverTo.trim() || undefined,
    });

    if (!result.success) {
      setErrorMessage(result.message || 'Failed to submit request.');
    } else {
      setSuccessMessage('Leave request submitted successfully into manager queue!');
      setTimeout(() => {
        setSuccessMessage('');
        onClose();
      }, 1000);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-lg w-full p-6 space-y-4 my-8">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div>
            <h2 className="text-sm font-bold text-slate-900">
              Submit PTO / Leave Request
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Accrual policy checks and workflow delegation
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 transition-colors p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {errorMessage && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded text-xs text-rose-800 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded text-xs text-emerald-800 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            <span>{successMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Employee Selector */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Applying Employee
            </label>
            <select
              value={employeeId}
              onChange={(e) => setEmployeeId(e.target.value)}
              className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
            >
              {employees.map(emp => (
                <option key={emp.id} value={emp.id}>
                  {emp.name} — {emp.role} ({emp.department})
                </option>
              ))}
            </select>
          </div>

          {/* Leave Type & Balance Display */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Leave Category
              </label>
              <select
                value={leaveType}
                onChange={(e) => setLeaveType(e.target.value as LeaveType)}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
              >
                <option value="annual">Annual Vacation</option>
                <option value="sick">Medical / Sick</option>
                <option value="casual">Casual / Personal</option>
                <option value="parental">Parental Leave</option>
                <option value="unpaid">Unpaid Leave</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Remaining Quota
              </label>
              <div className="p-2 bg-slate-100 border border-slate-200 rounded text-slate-800 font-mono">
                <span className={`font-bold ${isOverQuota ? 'text-rose-600' : 'text-emerald-700'}`}>
                  {availableBalance} days available
                </span>
              </div>
            </div>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Start Date
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                required
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                End Date
              </label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                required
              />
            </div>
          </div>

          {/* Duration Summary */}
          <div className="p-2.5 bg-slate-50 rounded border border-slate-200 flex items-center justify-between text-xs">
            <span className="text-slate-600">Calculated duration:</span>
            <span className="font-mono font-bold text-slate-900">
              {daysCount} {daysCount === 1 ? 'business day' : 'business days'}
            </span>
          </div>

          {/* Handover Colleague */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Coverage / Handover Contact (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Marcus Vance or Tariq Al-Mansoor"
              value={handoverTo}
              onChange={(e) => setHandoverTo(e.target.value)}
              className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
            />
          </div>

          {/* Reason */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Purpose & Details
            </label>
            <textarea
              rows={3}
              placeholder="Provide context regarding vacation plans, dental appointments, or urgent personal matters..."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full p-2 bg-slate-50 border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
              required
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isOverQuota}
              className={`px-4 py-2 text-white font-semibold rounded shadow-xs transition-colors ${
                isOverQuota 
                  ? 'bg-slate-400 cursor-not-allowed' 
                  : 'bg-indigo-600 hover:bg-indigo-700'
              }`}
            >
              Submit For Approval
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
