import React from 'react';
import { 
  Bell, 
  Search, 
  Plus, 
  Radio, 
  Clock, 
  Calendar,
  Building,
  CheckCircle2,
  FileSpreadsheet
} from 'lucide-react';
import { useHR } from '../../context/HRContext';
import { ActiveTab } from './Sidebar';

interface HeaderProps {
  activeTab: ActiveTab;
  onOpenLeaveModal: () => void;
  onOpenManualAttendance: () => void;
  onOpenReviewModal: () => void;
  searchTerm: string;
  setSearchTerm: (s: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onOpenLeaveModal,
  onOpenManualAttendance,
  onOpenReviewModal,
  searchTerm,
  setSearchTerm,
}) => {
  const { currentTimeString, isRealtimeActive, setIsRealtimeActive, employees } = useHR();

  const getBreadcrumbTitle = () => {
    switch (activeTab) {
      case 'overview': return 'Workforce Operations / Executive Overview';
      case 'attendance': return 'Time & Attendance / Live Punch Monitoring';
      case 'leaves': return 'Leave Management / Requests & Accruals';
      case 'performance': return 'Talent & Reviews / Performance Index';
      case 'directory': return 'People Operations / Employee Roster';
      default: return 'Workforce Operations';
    }
  };

  const getSubTitle = () => {
    switch (activeTab) {
      case 'overview': return 'Real-time corporate attendance, pending workflow approvals, and department scorecards';
      case 'attendance': return 'Live biometric and remote check-in feeds, shift durations, and daily logs';
      case 'leaves': return 'Pending PTO approvals, sickness reporting, and entitlement quota balances';
      case 'performance': return 'Quarterly OKR progress, 360-degree talent appraisals, and manager scorecards';
      case 'directory': return 'Staff records, department allocations, and personal profile dossiers';
      default: return '';
    }
  };

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between gap-4 sticky top-0 z-20">
      {/* Left: Breadcrumbs */}
      <div className="min-w-0">
        <div className="text-xs font-mono text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
          <span>Krona Enterprise</span>
          <span>/</span>
          <span className="text-slate-900 font-semibold">{getBreadcrumbTitle()}</span>
        </div>
        <p className="text-xs text-slate-500 truncate hidden md:block mt-0.5">
          {getSubTitle()}
        </p>
      </div>

      {/* Right: Live Telemetry & Actions */}
      <div className="flex items-center gap-3 shrink-0">
        {/* Real-time Heartbeat & Clock */}
        <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-md bg-slate-100 border border-slate-200 text-xs">
          <button 
            onClick={() => setIsRealtimeActive(!isRealtimeActive)}
            title={isRealtimeActive ? "Real-time sync is active. Click to pause." : "Real-time sync paused. Click to resume."}
            className="flex items-center gap-1.5 text-slate-600 hover:text-slate-900 transition-colors"
          >
            <Radio className={`w-3.5 h-3.5 ${isRealtimeActive ? 'text-emerald-600 animate-pulse' : 'text-slate-400'}`} />
            <span className="font-medium text-[11px]">
              {isRealtimeActive ? 'LIVE' : 'PAUSED'}
            </span>
          </button>
          <span className="text-slate-300">|</span>
          <div className="flex items-center gap-1 text-slate-700 font-mono text-xs font-semibold tabular-nums">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
            <span>{currentTimeString}</span>
          </div>
        </div>

        {/* Global Search Bar */}
        <div className="relative hidden lg:block w-48 xl:w-60">
          <label htmlFor="global-search" className="sr-only">Search employees or IDs</label>
          <Search className="w-4 h-4 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            id="global-search"
            type="text"
            placeholder="Search staff, ID, department..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-slate-900 focus:bg-white transition-all placeholder:text-slate-400"
          />
        </div>

        {/* Primary Context Actions */}
        {activeTab === 'attendance' && (
          <button
            onClick={onOpenManualAttendance}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-50 hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Log Attendance</span>
          </button>
        )}

        {activeTab === 'performance' && (
          <button
            onClick={onOpenReviewModal}
            className="px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Performance Review</span>
          </button>
        )}

        <button
          onClick={onOpenLeaveModal}
          className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-md hover:bg-indigo-700 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 shadow-sm"
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Apply Leave</span>
        </button>
      </div>
    </header>
  );
};
