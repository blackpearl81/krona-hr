import React from 'react';
import { 
  LayoutDashboard, 
  Clock, 
  CalendarCheck, 
  TrendingUp, 
  Users, 
  Building2, 
  RefreshCw,
  LogOut,
  Coffee,
  CheckCircle2,
  ChevronDown
} from 'lucide-react';
import { useHR } from '../../context/HRContext';

export type ActiveTab = 'overview' | 'attendance' | 'leaves' | 'performance' | 'directory';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenLeaveModal: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, onOpenLeaveModal }) => {
  const { 
    currentUser, 
    employees, 
    switchCurrentUser, 
    leaveRequests, 
    clockIn, 
    clockOut, 
    toggleBreak,
    resetAllData 
  } = useHR();

  const pendingLeavesCount = leaveRequests.filter(r => r.status === 'pending').length;
  const isClockedIn = currentUser.todayStatus === 'present' || currentUser.todayStatus === 'remote';
  const isOnBreak = currentUser.todayStatus === 'on_break';

  const navItems: { id: ActiveTab; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'overview', label: 'Executive Pulse', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'attendance', label: 'Attendance & Time', icon: <Clock className="w-4 h-4" /> },
    { id: 'leaves', label: 'Leave Requests', icon: <CalendarCheck className="w-4 h-4" />, badge: pendingLeavesCount },
    { id: 'performance', label: 'Performance & OKRs', icon: <TrendingUp className="w-4 h-4" /> },
    { id: 'directory', label: 'Employee Directory', icon: <Users className="w-4 h-4" /> },
  ];

  return (
    <aside className="w-64 bg-slate-900 text-slate-200 flex flex-col shrink-0 border-r border-slate-800 select-none">
      {/* Brand Header */}
      <div className="h-16 px-5 flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-indigo-600 flex items-center justify-center text-white font-semibold text-base shadow-sm">
            K
          </div>
          <div>
            <span className="font-bold tracking-tight text-white text-base block leading-tight">
              Krona HR
            </span>
            <span className="text-[11px] text-slate-400 font-mono tracking-wider block">
              ENTERPRISE HRMS
            </span>
          </div>
        </div>
      </div>

      {/* Primary Navigation */}
      <nav className="p-3 space-y-1 flex-1">
        <div className="px-3 py-2 text-[11px] font-semibold text-slate-300 uppercase tracking-wider">
          Operations
        </div>
        {navItems.map(item => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-md text-xs font-medium transition-colors text-left ${
                isActive
                  ? 'bg-slate-800 text-white font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className={isActive ? 'text-indigo-400' : 'text-slate-400'}>
                  {item.icon}
                </span>
                <span>{item.label}</span>
              </div>
              {item.badge !== undefined && item.badge > 0 && (
                <span className="text-[10px] font-mono font-medium px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}

        <div className="pt-6 px-3 py-2 text-[11px] font-semibold text-slate-300 uppercase tracking-wider">
          Quick Actions
        </div>
        <button
          onClick={onOpenLeaveModal}
          className="w-full flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800/50 rounded-md transition-colors"
        >
          <CalendarCheck className="w-4 h-4 text-emerald-400" />
          <span>Submit Leave Request</span>
        </button>
        <button
          onClick={resetAllData}
          title="Reset modified state to initial seeds"
          className="w-full flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-300 hover:text-slate-200 hover:bg-slate-800/50 rounded-md transition-colors"
        >
          <RefreshCw className="w-4 h-4 text-slate-400" />
          <span>Reset Sample Data</span>
        </button>
      </nav>

      {/* User Switcher & Personal Punch Card */}
      <div className="p-3 border-t border-slate-800 bg-slate-950/40">
        <div className="mb-2 px-1 flex items-center justify-between">
          <span className="text-[10px] uppercase font-semibold tracking-wider text-slate-400">
            Active Persona
          </span>
          <div className="relative group">
            <label htmlFor="persona-select" className="sr-only">Switch User</label>
            <select
              id="persona-select"
              aria-label="Switch active user persona"
              value={currentUser.id}
              onChange={(e) => switchCurrentUser(e.target.value)}
              className="opacity-0 absolute inset-0 w-full h-full cursor-pointer z-10"
            >
              {employees.map(e => (
                <option key={e.id} value={e.id} className="bg-slate-900 text-slate-200">
                  {e.name} ({e.department})
                </option>
              ))}
            </select>
            <span className="text-[11px] text-indigo-400 hover:text-indigo-300 cursor-pointer flex items-center gap-1">
              Switch <ChevronDown className="w-3 h-3" />
            </span>
          </div>
        </div>

        {/* Current User Card */}
        <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700/60 mb-2">
          <div className="flex items-center gap-2.5">
            {currentUser.avatarUrl ? (
              <img
                src={currentUser.avatarUrl}
                alt={currentUser.name}
                referrerPolicy="no-referrer"
                className="w-9 h-9 rounded-full object-cover shrink-0 ring-1 ring-slate-600"
              />
            ) : (
              <div className="w-9 h-9 rounded-full bg-slate-700 text-white flex items-center justify-center font-medium text-xs shrink-0">
                {currentUser.name.split(' ').map(n => n[0]).join('')}
              </div>
            )}
            <div className="min-w-0 flex-1">
              <div className="text-xs font-semibold text-white truncate">
                {currentUser.name}
              </div>
              <div className="text-[11px] text-slate-400 truncate">
                {currentUser.role}
              </div>
            </div>
          </div>

          {/* User attendance status line */}
          <div className="mt-2.5 pt-2 border-t border-slate-700/60 flex items-center justify-between text-[11px]">
            <span className="text-slate-400">Shift status:</span>
            <span className={`font-medium ${
              isOnBreak ? 'text-amber-400' : isClockedIn ? 'text-emerald-400' : 'text-slate-400'
            }`}>
              {isOnBreak ? 'On Break' : isClockedIn ? 'Clocked In' : 'Clocked Out'}
            </span>
          </div>

          {/* Action buttons for current user */}
          <div className="mt-2 grid grid-cols-2 gap-1.5">
            {!isClockedIn ? (
              <button
                onClick={() => clockIn(currentUser.id, 'Office')}
                className="col-span-2 py-1.5 px-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded transition-colors text-center"
              >
                Clock In (HQ)
              </button>
            ) : (
              <>
                <button
                  onClick={() => toggleBreak(currentUser.id)}
                  className={`py-1 px-2 text-[11px] font-medium rounded transition-colors flex items-center justify-center gap-1 ${
                    isOnBreak
                      ? 'bg-amber-600 text-white hover:bg-amber-500'
                      : 'bg-slate-700 text-slate-200 hover:bg-slate-600'
                  }`}
                >
                  <Coffee className="w-3 h-3" />
                  <span>{isOnBreak ? 'Resume' : 'Break'}</span>
                </button>
                <button
                  onClick={() => clockOut(currentUser.id)}
                  className="py-1 px-2 bg-slate-700 hover:bg-rose-700 text-slate-200 hover:text-white text-[11px] font-medium rounded transition-colors flex items-center justify-center gap-1"
                >
                  <LogOut className="w-3 h-3" />
                  <span>End Shift</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </aside>
  );
};
