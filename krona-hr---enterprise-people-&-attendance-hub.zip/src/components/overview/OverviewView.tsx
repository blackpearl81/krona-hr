import React from 'react';
import { 
  Users, 
  Clock, 
  CalendarCheck, 
  TrendingUp, 
  ArrowUpRight, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  Building,
  Laptop,
  Coffee,
  Check,
  X,
  Radio,
  ChevronRight
} from 'lucide-react';
import { useHR } from '../../context/HRContext';
import { ActiveTab } from '../layout/Sidebar';
import { DepartmentName } from '../../types/hr';

interface OverviewViewProps {
  setActiveTab: (tab: ActiveTab) => void;
  onOpenLeaveModal: () => void;
  onOpenReviewModal: () => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({ 
  setActiveTab, 
  onOpenLeaveModal,
  onOpenReviewModal
}) => {
  const { 
    employees, 
    leaveRequests, 
    liveEvents, 
    approveLeave, 
    rejectLeave,
    setSelectedEmployeeForDrawer,
    isRealtimeActive
  } = useHR();

  // Calculations
  const totalEmployees = employees.length;
  const presentCount = employees.filter(e => e.todayStatus === 'present').length;
  const remoteCount = employees.filter(e => e.todayStatus === 'remote').length;
  const onBreakCount = employees.filter(e => e.todayStatus === 'on_break').length;
  const lateCount = employees.filter(e => e.todayStatus === 'late').length;
  const absentCount = employees.filter(e => e.todayStatus === 'absent').length;
  const onLeaveCount = employees.filter(e => e.todayStatus === 'on_leave').length;

  const activeWorkingCount = presentCount + remoteCount + onBreakCount + lateCount;
  const attendanceRate = ((activeWorkingCount / totalEmployees) * 100).toFixed(1);

  const pendingLeaves = leaveRequests.filter(r => r.status === 'pending');
  const avgPerformance = (
    employees.reduce((acc, curr) => acc + curr.performanceScore, 0) / totalEmployees
  ).toFixed(1);

  const departments: DepartmentName[] = [
    'Engineering',
    'Product',
    'Design',
    'Sales',
    'Marketing',
    'Operations',
    'People & HR',
  ];

  const departmentStats = departments.map(dept => {
    const deptEmployees = employees.filter(e => e.department === dept);
    const deptWorking = deptEmployees.filter(e => 
      e.todayStatus === 'present' || e.todayStatus === 'remote' || e.todayStatus === 'late' || e.todayStatus === 'on_break'
    ).length;
    const rate = deptEmployees.length > 0 
      ? Math.round((deptWorking / deptEmployees.length) * 100) 
      : 100;
    return {
      name: dept,
      total: deptEmployees.length,
      working: deptWorking,
      rate,
    };
  });

  return (
    <div className="space-y-6">
      {/* Top 4 KPI Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Attendance Rate */}
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>Daily Attendance Rate</span>
            <Clock className="w-4 h-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tracking-tight text-slate-900 tabular-nums">
              {attendanceRate}%
            </span>
            <span className="text-xs font-mono text-emerald-700 font-semibold tabular-nums">
              {activeWorkingCount}/{totalEmployees} active
            </span>
          </div>
          <div className="mt-3 flex items-center gap-1.5 text-xs text-slate-500">
            <span>In Office {presentCount + lateCount}</span>
            <span aria-hidden="true">·</span>
            <span>Remote {remoteCount}</span>
            <span aria-hidden="true">·</span>
            <span>Break {onBreakCount}</span>
          </div>
        </div>

        {/* KPI 2: Pending Leave Requests */}
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>Pending Leave Requests</span>
            <CalendarCheck className="w-4 h-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tracking-tight text-slate-900 tabular-nums">
              {pendingLeaves.length}
            </span>
            <span className="text-xs text-slate-500">
              awaiting review
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs">
            <span className="text-slate-500">{onLeaveCount} employee(s) away today</span>
            <button
              onClick={() => setActiveTab('leaves')}
              className="text-indigo-600 hover:text-indigo-800 font-medium flex items-center gap-0.5"
            >
              Review queue <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* KPI 3: Company Performance Score */}
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>Avg Performance Rating</span>
            <TrendingUp className="w-4 h-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tracking-tight text-slate-900 tabular-nums">
              {avgPerformance}
            </span>
            <span className="text-xs font-mono text-slate-500 tabular-nums">
              / 5.0 Q3 Metric
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs">
            <span className="text-slate-500">84% review cycle completion</span>
            <button
              onClick={() => setActiveTab('performance')}
              className="text-indigo-600 hover:text-indigo-800 font-medium flex items-center gap-0.5"
            >
              Scorecard <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* KPI 4: Total Headcount */}
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>Active Headcount</span>
            <Users className="w-4 h-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tracking-tight text-slate-900 tabular-nums">
              {totalEmployees}
            </span>
            <span className="text-xs text-slate-500">
              across 7 departments
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs">
            <span className="text-slate-500">100% contracted full-time</span>
            <button
              onClick={() => setActiveTab('directory')}
              className="text-indigo-600 hover:text-indigo-800 font-medium flex items-center gap-0.5"
            >
              Directory <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Main 2-Column Split: Pending Leaves & Real-time Activity Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 Cols): Actionable Pending Leave Queue + Live Shift Breakdown */}
        <div className="lg:col-span-2 space-y-6">
          {/* Section: Pending Leave Workflow */}
          <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h2 className="text-sm font-semibold text-slate-900">
                  Priority Leave Requests Awaiting Action
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Approve or decline time-off submissions with audit logging
                </p>
              </div>
              <button
                onClick={() => setActiveTab('leaves')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
              >
                View all ({leaveRequests.length})
              </button>
            </div>

            {pendingLeaves.length === 0 ? (
              <div className="p-8 text-center">
                <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                <h3 className="text-sm font-semibold text-slate-800">All caught up!</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                  There are no pending leave requests in the queue. New submissions will appear here in real-time.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {pendingLeaves.map(req => (
                  <div key={req.id} className="p-4 hover:bg-slate-50 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => {
                            const emp = employees.find(e => e.id === req.employeeId);
                            if (emp) setSelectedEmployeeForDrawer(emp);
                          }}
                          className="text-xs font-semibold text-slate-900 hover:text-indigo-600 transition-colors text-left"
                        >
                          {req.employeeName}
                        </button>
                        <span className="text-xs text-slate-400">·</span>
                        <span className="text-xs text-slate-500">{req.department}</span>
                        <span className="text-xs text-slate-400">·</span>
                        <span className="text-xs font-mono font-medium text-slate-700 capitalize">
                          {req.leaveType} leave ({req.daysCount} {req.daysCount === 1 ? 'day' : 'days'})
                        </span>
                      </div>
                      <div className="text-xs text-slate-600 flex items-center gap-2">
                        <span className="font-mono text-slate-500">{req.startDate} to {req.endDate}</span>
                        {req.handoverTo && (
                          <>
                            <span className="text-slate-300">|</span>
                            <span className="text-slate-500">Handover: {req.handoverTo}</span>
                          </>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 italic">
                        "{req.reason}"
                      </p>
                    </div>

                    {/* Action buttons */}
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => approveLeave(req.id)}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Approve</span>
                      </button>
                      <button
                        onClick={() => rejectLeave(req.id)}
                        className="px-3 py-1.5 bg-white hover:bg-rose-50 text-rose-700 border border-rose-300 rounded text-xs font-semibold flex items-center gap-1.5 transition-colors"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>Reject</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Department Attendance Matrix */}
          <div className="bg-white rounded-lg border border-slate-200 p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-sm font-semibold text-slate-900">
                  Department Attendance Breakdown
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Real-time workforce participation across corporate divisions
                </p>
              </div>
              <span className="text-xs font-mono text-slate-500">
                Today's Snapshot
              </span>
            </div>

            <div className="space-y-3">
              {departmentStats.map(stat => (
                <div key={stat.name} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-800">{stat.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-slate-500 tabular-nums">
                        {stat.working}/{stat.total} on duty
                      </span>
                      <span className="font-mono font-semibold text-slate-900 w-10 text-right tabular-nums">
                        {stat.rate}%
                      </span>
                    </div>
                  </div>
                  <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all duration-500 ${
                        stat.rate >= 90 ? 'bg-emerald-500' : stat.rate >= 70 ? 'bg-indigo-500' : 'bg-amber-500'
                      }`}
                      style={{ width: `${stat.rate}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (1 Col): Live Event Stream & Quick Shift Status */}
        <div className="space-y-6">
          {/* Shift Distribution Card */}
          <div className="bg-white rounded-lg border border-slate-200 p-4">
            <h2 className="text-sm font-semibold text-slate-900 mb-3">
              Today's Presence Distribution
            </h2>
            <div className="space-y-2.5">
              <div className="flex items-center justify-between text-xs py-1.5 border-b border-slate-100">
                <span className="text-slate-600 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span>
                  In Office (Physical)
                </span>
                <span className="font-mono font-semibold text-slate-900 tabular-nums">
                  {presentCount} ({Math.round((presentCount / totalEmployees) * 100)}%)
                </span>
              </div>
              <div className="flex items-center justify-between text-xs py-1.5 border-b border-slate-100">
                <span className="text-slate-600 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-indigo-500 shrink-0"></span>
                  Remote / Telework
                </span>
                <span className="font-mono font-semibold text-slate-900 tabular-nums">
                  {remoteCount} ({Math.round((remoteCount / totalEmployees) * 100)}%)
                </span>
              </div>
              <div className="flex items-center justify-between text-xs py-1.5 border-b border-slate-100">
                <span className="text-slate-600 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0"></span>
                  Rest Break
                </span>
                <span className="font-mono font-semibold text-slate-900 tabular-nums">
                  {onBreakCount}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs py-1.5 border-b border-slate-100">
                <span className="text-slate-600 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-orange-500 shrink-0"></span>
                  Late Arrival
                </span>
                <span className="font-mono font-semibold text-slate-900 tabular-nums">
                  {lateCount}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs py-1.5 border-b border-slate-100">
                <span className="text-slate-600 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-blue-500 shrink-0"></span>
                  Approved Leave
                </span>
                <span className="font-mono font-semibold text-slate-900 tabular-nums">
                  {onLeaveCount}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs py-1.5">
                <span className="text-slate-600 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0"></span>
                  Unexcused Absent
                </span>
                <span className="font-mono font-semibold text-slate-900 tabular-nums">
                  {absentCount}
                </span>
              </div>
            </div>
          </div>

          {/* Real-time Activity Stream */}
          <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-2">
                <Radio className={`w-3.5 h-3.5 ${isRealtimeActive ? 'text-emerald-500 animate-pulse' : 'text-slate-400'}`} />
                <h2 className="text-xs font-semibold text-slate-900 uppercase tracking-wider">
                  Live Operations Stream
                </h2>
              </div>
              <span className="text-[11px] font-mono text-slate-400">
                Real-Time Feed
              </span>
            </div>

            <div className="p-3 max-h-96 overflow-y-auto divide-y divide-slate-100 text-xs">
              {liveEvents.length === 0 ? (
                <div className="py-6 text-center text-slate-400">No events recorded yet.</div>
              ) : (
                liveEvents.map(evt => (
                  <div key={evt.id} className="py-2.5 first:pt-1 last:pb-1">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="font-semibold text-slate-900 truncate">
                        {evt.employeeName}
                      </span>
                      <span className="text-[11px] font-mono text-slate-500 tabular-nums shrink-0">
                        {evt.timestamp}
                      </span>
                    </div>
                    <p className="text-slate-600 text-xs leading-relaxed">
                      {evt.description}
                    </p>
                    <div className="mt-1 text-[11px] text-slate-500">
                      <span>{evt.department}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
