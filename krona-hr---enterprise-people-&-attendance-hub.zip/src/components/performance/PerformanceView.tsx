import React, { useState } from 'react';
import { 
  TrendingUp, 
  Award, 
  Target, 
  Star, 
  Plus, 
  CheckCircle2, 
  AlertCircle, 
  ChevronRight,
  BarChart3,
  User,
  Sliders,
  Sparkles
} from 'lucide-react';
import { useHR } from '../../context/HRContext';
import { Employee, DepartmentName } from '../../types/hr';

interface PerformanceViewProps {
  onOpenReviewModal: () => void;
}

export const PerformanceView: React.FC<PerformanceViewProps> = ({ onOpenReviewModal }) => {
  const { 
    employees, 
    performanceReviews, 
    updateGoalProgress, 
    setSelectedEmployeeForDrawer 
  } = useHR();

  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<'goals' | 'reviews' | 'benchmarks'>('goals');

  // Calculations
  const allGoals = employees.flatMap(emp => 
    emp.keyGoals.map(g => ({ ...g, employeeName: emp.name, employeeId: emp.id, department: emp.department }))
  );
  
  const completedGoalsCount = allGoals.filter(g => g.status === 'completed').length;
  const onTrackGoalsCount = allGoals.filter(g => g.status === 'on_track').length;
  const atRiskGoalsCount = allGoals.filter(g => g.status === 'at_risk').length;
  const goalSuccessRate = Math.round(((completedGoalsCount + onTrackGoalsCount) / allGoals.length) * 100);

  const topPerformers = employees.filter(e => e.performanceScore >= 4.7);

  const filteredGoals = allGoals.filter(g => {
    if (departmentFilter !== 'all' && g.department !== departmentFilter) return false;
    return true;
  });

  const departmentScores: { name: DepartmentName; avgScore: number; count: number }[] = [
    'Engineering',
    'Product',
    'Design',
    'People & HR',
    'Sales',
    'Marketing',
    'Operations',
  ].map(dept => {
    const list = employees.filter(e => e.department === dept);
    const avg = list.length > 0 
      ? Number((list.reduce((acc, curr) => acc + curr.performanceScore, 0) / list.length).toFixed(2))
      : 0;
    return { name: dept as DepartmentName, avgScore: avg, count: list.length };
  });

  return (
    <div className="space-y-6">
      {/* Top Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>Corporate OKR Health</span>
            <Target className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
              {goalSuccessRate}%
            </span>
            <span className="text-xs font-mono text-emerald-700 font-medium tabular-nums">
              {completedGoalsCount} completed · {onTrackGoalsCount} on track
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Across {allGoals.length} key quarterly company milestones
          </p>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>High Performance Tier</span>
            <Award className="w-4 h-4 text-amber-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
              {topPerformers.length}
            </span>
            <span className="text-xs text-slate-500">
              staff members rated $\ge 4.7$
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Eligible for Q3 annual merit bonus calibration
          </p>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>Active Appraisal Cycle</span>
            <BarChart3 className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
              Q3 2026
            </span>
            <span className="text-xs text-slate-500">
              calibration in progress
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            {performanceReviews.length} formal 360-evaluations submitted
          </p>
        </div>
      </div>

      {/* Segmented View Switcher & Actions */}
      <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex items-center bg-slate-100 p-0.5 rounded-md text-xs">
              <button
                onClick={() => setActiveTab('goals')}
                className={`px-3 py-1.5 rounded font-medium transition-colors ${
                  activeTab === 'goals' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Key Goals & OKRs ({allGoals.length})
              </button>
              <button
                onClick={() => setActiveTab('reviews')}
                className={`px-3 py-1.5 rounded font-medium transition-colors ${
                  activeTab === 'reviews' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                360° Appraisals ({performanceReviews.length})
              </button>
              <button
                onClick={() => setActiveTab('benchmarks')}
                className={`px-3 py-1.5 rounded font-medium transition-colors ${
                  activeTab === 'benchmarks' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Department Benchmarks
              </button>
            </div>

            {activeTab === 'goals' && (
              <div className="flex items-center gap-1.5 text-xs">
                <span className="text-slate-500">Department:</span>
                <label htmlFor="dept-filter-performance" className="sr-only">Filter by department</label>
                <select
                  id="dept-filter-performance"
                  aria-label="Filter by department"
                  value={departmentFilter}
                  onChange={(e) => setDepartmentFilter(e.target.value)}
                  className="py-1 px-2.5 text-xs bg-slate-50 border border-slate-200 rounded text-slate-800 focus:outline-none"
                >
                  <option value="all">All</option>
                  <option value="Engineering">Engineering</option>
                  <option value="Product">Product</option>
                  <option value="Design">Design</option>
                  <option value="Sales">Sales</option>
                  <option value="Marketing">Marketing</option>
                  <option value="Operations">Operations</option>
                  <option value="People & HR">People & HR</option>
                </select>
              </div>
            )}
          </div>

          <button
            onClick={onOpenReviewModal}
            className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Submit Performance Review</span>
          </button>
        </div>

        {/* Tab 1: Key Goals & OKRs */}
        {activeTab === 'goals' && (
          <div className="divide-y divide-slate-100">
            {filteredGoals.map(goal => (
              <div key={goal.id} className="p-4 hover:bg-slate-50/60 transition-colors">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1.5 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs font-semibold text-slate-900">
                        {goal.title}
                      </span>
                      <span className="text-slate-300">·</span>
                      <button
                        onClick={() => {
                          const emp = employees.find(e => e.id === goal.employeeId);
                          if (emp) setSelectedEmployeeForDrawer(emp);
                        }}
                        className="text-xs text-indigo-600 hover:text-indigo-800 font-medium"
                      >
                        {goal.employeeName}
                      </button>
                      <span className="text-slate-300">·</span>
                      <span className="text-xs text-slate-500">{goal.department}</span>
                      <span className="text-slate-300">·</span>
                      <span className="text-xs font-mono text-slate-500 uppercase tracking-wider">
                        {goal.category}
                      </span>
                    </div>

                    <div className="flex items-center gap-3 text-xs text-slate-500">
                      <span>Target: {goal.targetDate}</span>
                      <span className="text-slate-300">|</span>
                      <span className={`font-semibold ${
                        goal.status === 'completed' ? 'text-emerald-700' :
                        goal.status === 'on_track' ? 'text-indigo-700' : 'text-amber-700'
                      }`}>
                        {goal.status === 'completed' ? 'Completed' : goal.status === 'on_track' ? 'On Track' : 'At Risk'}
                      </span>
                    </div>

                    {/* Progress Bar & Slider */}
                    <div className="w-full max-w-md space-y-1 pt-1">
                      <div className="flex items-center justify-between text-[11px] text-slate-600 font-mono">
                        <span>Milestone Progress</span>
                        <span className="font-semibold text-slate-900 tabular-nums">
                          {goal.progressPercent}%
                        </span>
                      </div>
                      <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-300 ${
                            goal.progressPercent === 100 ? 'bg-emerald-500' :
                            goal.progressPercent < 50 ? 'bg-amber-500' : 'bg-indigo-600'
                          }`}
                          style={{ width: `${goal.progressPercent}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Interactive Quick Adjuster */}
                  <div className="flex items-center gap-1.5 shrink-0 self-start sm:self-center">
                    <button
                      onClick={() => updateGoalProgress(goal.employeeId, goal.id, Math.max(0, goal.progressPercent - 10))}
                      disabled={goal.progressPercent <= 0}
                      className="px-2 py-1 border border-slate-200 rounded text-xs text-slate-600 hover:bg-slate-100 disabled:opacity-40"
                    >
                      -10%
                    </button>
                    <button
                      onClick={() => updateGoalProgress(goal.employeeId, goal.id, Math.min(100, goal.progressPercent + 10))}
                      disabled={goal.progressPercent >= 100}
                      className="px-2 py-1 border border-slate-200 rounded text-xs text-slate-600 hover:bg-slate-100 disabled:opacity-40"
                    >
                      +10%
                    </button>
                    <button
                      onClick={() => updateGoalProgress(goal.employeeId, goal.id, 100)}
                      className="px-2.5 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 rounded text-xs font-semibold"
                    >
                      Complete
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Tab 2: Formal 360 Appraisals */}
        {activeTab === 'reviews' && (
          <div className="p-5 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {performanceReviews.map(rev => (
                <div key={rev.id} className="p-4 rounded-lg border border-slate-200 bg-slate-50/40 space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-xs font-bold text-slate-900">
                        {rev.employeeName}
                      </h3>
                      <p className="text-[11px] text-slate-500">
                        Evaluated by {rev.reviewerName} · {rev.reviewPeriod}
                      </p>
                    </div>
                    <div className="flex items-center gap-1 bg-indigo-50 border border-indigo-200 px-2 py-1 rounded">
                      <Star className="w-3.5 h-3.5 fill-indigo-600 text-indigo-600" />
                      <span className="font-mono font-bold text-xs text-indigo-900 tabular-nums">
                        {rev.ratingOverall.toFixed(1)} / 5.0
                      </span>
                    </div>
                  </div>

                  {/* Competencies breakdown */}
                  <div className="space-y-1.5 text-[11px]">
                    <div className="flex justify-between text-slate-600">
                      <span>Leadership & Initiative:</span>
                      <span className="font-mono font-medium text-slate-900">{rev.competencies.leadership}/5.0</span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>Technical & Domain Knowledge:</span>
                      <span className="font-mono font-medium text-slate-900">{rev.competencies.jobKnowledge}/5.0</span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>Team Collaboration:</span>
                      <span className="font-mono font-medium text-slate-900">{rev.competencies.teamCollaboration}/5.0</span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>Execution Speed & Quality:</span>
                      <span className="font-mono font-medium text-slate-900">{rev.competencies.deliverySpeed}/5.0</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-200 space-y-1 text-xs">
                    <p className="text-slate-800">
                      <strong className="text-slate-900 font-semibold">Key Win:</strong> {rev.achievements}
                    </p>
                    <p className="text-slate-600 italic">
                      <strong className="text-slate-700 not-italic font-semibold">Growth Opportunity:</strong> {rev.areasToGrow}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: Department Benchmarks */}
        {activeTab === 'benchmarks' && (
          <div className="p-5">
            <h3 className="text-xs font-semibold text-slate-900 uppercase tracking-wider mb-4">
              Cross-Department Performance Ratings (Out of 5.0)
            </h3>
            <div className="space-y-4">
              {departmentScores.map(dept => (
                <div key={dept.name} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-800">{dept.name} ({dept.count} members)</span>
                    <span className="font-mono font-bold text-slate-900 tabular-nums">
                      {dept.avgScore} / 5.0
                    </span>
                  </div>
                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-indigo-600 rounded-full transition-all"
                      style={{ width: `${(dept.avgScore / 5.0) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
