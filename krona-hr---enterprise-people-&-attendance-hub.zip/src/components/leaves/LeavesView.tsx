import React, { useState } from 'react';
import { 
  CalendarCheck, 
  Clock, 
  Check, 
  X, 
  Filter, 
  Plus, 
  AlertCircle, 
  ChevronRight, 
  User, 
  ShieldCheck, 
  Search,
  MessageSquare,
  FileText
} from 'lucide-react';
import { useHR } from '../../context/HRContext';
import { LeaveRequest, LeaveStatus, LeaveType } from '../../types/hr';

interface LeavesViewProps {
  onOpenLeaveModal: () => void;
}

export const LeavesView: React.FC<LeavesViewProps> = ({ onOpenLeaveModal }) => {
  const { 
    leaveRequests, 
    approveLeave, 
    rejectLeave, 
    currentUser, 
    employees, 
    setSelectedEmployeeForDrawer 
  } = useHR();

  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [rejectionModalRequest, setRejectionModalRequest] = useState<LeaveRequest | null>(null);
  const [rejectReason, setRejectReason] = useState<string>('');

  // Filter requests
  const filteredRequests = leaveRequests.filter(req => {
    if (statusFilter !== 'all' && req.status !== statusFilter) return false;
    if (typeFilter !== 'all' && req.leaveType !== typeFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = req.employeeName.toLowerCase().includes(q);
      const matchReason = req.reason.toLowerCase().includes(q);
      const matchDept = req.department.toLowerCase().includes(q);
      if (!matchName && !matchReason && !matchDept) return false;
    }
    return true;
  });

  const pendingCount = leaveRequests.filter(r => r.status === 'pending').length;
  const approvedCount = leaveRequests.filter(r => r.status === 'approved').length;
  const rejectedCount = leaveRequests.filter(r => r.status === 'rejected').length;

  const handleConfirmReject = () => {
    if (rejectionModalRequest) {
      rejectLeave(rejectionModalRequest.id, rejectReason || 'Declined due to team operational bandwidth.');
      setRejectionModalRequest(null);
      setRejectReason('');
    }
  };

  const getStatusTextClass = (status: LeaveStatus) => {
    switch (status) {
      case 'approved': return 'text-emerald-700';
      case 'pending': return 'text-amber-700';
      case 'rejected': return 'text-rose-700';
      default: return 'text-slate-700';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Metric Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>Pending Review Queue</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
              {pendingCount}
            </span>
            <span className="text-xs text-slate-500">
              requests awaiting manager sign-off
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>Approved PTO Bookings</span>
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
              {approvedCount}
            </span>
            <span className="text-xs text-slate-500">
              processed this cycle
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>My Remaining Annual Quota</span>
            <CalendarCheck className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
              {currentUser.leaveBalances.annual.total - currentUser.leaveBalances.annual.used}
            </span>
            <span className="text-xs font-mono text-slate-500 tabular-nums">
              / {currentUser.leaveBalances.annual.total} days available ({currentUser.name.split(' ')[0]})
            </span>
          </div>
        </div>
      </div>

      {/* Main Leave Request Ledger & Controls */}
      <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
        {/* Filter Bar */}
        <div className="p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            {/* Search */}
            <div className="relative w-64">
              <label htmlFor="leave-search" className="sr-only">Search leave requests</label>
              <Search className="w-4 h-4 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="leave-search"
                type="text"
                placeholder="Search staff, reason, department..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-slate-900 focus:bg-white"
              />
            </div>

            {/* Segmented Status Selector */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-md text-xs">
              <button
                onClick={() => setStatusFilter('all')}
                className={`px-3 py-1 rounded font-medium transition-colors ${
                  statusFilter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All ({leaveRequests.length})
              </button>
              <button
                onClick={() => setStatusFilter('pending')}
                className={`px-3 py-1 rounded font-medium transition-colors ${
                  statusFilter === 'pending' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Pending ({pendingCount})
              </button>
              <button
                onClick={() => setStatusFilter('approved')}
                className={`px-3 py-1 rounded font-medium transition-colors ${
                  statusFilter === 'approved' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Approved ({approvedCount})
              </button>
              <button
                onClick={() => setStatusFilter('rejected')}
                className={`px-3 py-1 rounded font-medium transition-colors ${
                  statusFilter === 'rejected' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Declined ({rejectedCount})
              </button>
            </div>

            {/* Leave Type Filter */}
            <div className="flex items-center gap-1 text-xs">
              <span className="text-slate-500 font-medium">Type:</span>
              <label htmlFor="leave-type-filter" className="sr-only">Filter by leave type</label>
              <select
                id="leave-type-filter"
                aria-label="Filter by leave type"
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value)}
                className="py-1 px-2.5 text-xs bg-slate-50 border border-slate-200 rounded-md text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900"
              >
                <option value="all">All Types</option>
                <option value="annual">Annual Leave</option>
                <option value="sick">Sick Leave</option>
                <option value="casual">Casual Leave</option>
                <option value="parental">Parental Leave</option>
              </select>
            </div>
          </div>

          <button
            onClick={onOpenLeaveModal}
            className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Apply For Leave</span>
          </button>
        </div>

        {/* Requests List */}
        <div className="divide-y divide-slate-100">
          {filteredRequests.length === 0 ? (
            <div className="py-12 text-center text-slate-500 text-xs">
              No leave requests match the selected filters.
            </div>
          ) : (
            filteredRequests.map(req => {
              const statusClass = getStatusTextClass(req.status);
              return (
                <div key={req.id} className="p-4 hover:bg-slate-50/70 transition-colors">
                  <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                    {/* Left: Employee info & details */}
                    <div className="space-y-2 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          onClick={() => {
                            const emp = employees.find(e => e.id === req.employeeId);
                            if (emp) setSelectedEmployeeForDrawer(emp);
                          }}
                          className="font-semibold text-slate-900 hover:text-indigo-600 text-xs"
                        >
                          {req.employeeName}
                        </button>
                        <span className="text-slate-300">·</span>
                        <span className="text-slate-500 text-xs">{req.department}</span>
                        <span className="text-slate-300">·</span>
                        <span className="font-mono text-[11px] text-slate-400">{req.id}</span>
                        <span className="text-slate-300">·</span>
                        <span className={`text-xs font-semibold uppercase tracking-wider ${statusClass}`}>
                          {req.status}
                        </span>
                      </div>

                      {/* Date & Period */}
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-700">
                        <span className="font-medium capitalize text-slate-900">{req.leaveType} PTO:</span>
                        <span className="font-mono tabular-nums text-slate-600">
                          {req.startDate} to {req.endDate}
                        </span>
                        <span className="text-slate-400">·</span>
                        <span className="font-mono font-semibold tabular-nums text-slate-900">
                          {req.daysCount} business {req.daysCount === 1 ? 'day' : 'days'}
                        </span>
                        {req.handoverTo && (
                          <>
                            <span className="text-slate-300">·</span>
                            <span className="text-slate-500">Handover to: {req.handoverTo}</span>
                          </>
                        )}
                      </div>

                      {/* Reason */}
                      <p className="text-xs text-slate-600 italic bg-slate-50 p-2 rounded border border-slate-100 max-w-3xl">
                        "{req.reason}"
                      </p>

                      {/* Review history */}
                      {req.reviewedBy && (
                        <div className="text-[11px] text-slate-500 flex items-center gap-1.5 pt-1">
                          <span className="font-medium text-slate-700">Reviewed by {req.reviewedBy}</span>
                          <span>·</span>
                          <span>{req.reviewedAt}</span>
                          {req.reviewComment && (
                            <>
                              <span>·</span>
                              <span className="italic text-slate-600">Note: "{req.reviewComment}"</span>
                            </>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Right: Actions */}
                    <div className="flex items-center gap-2 shrink-0 pt-1">
                      {req.status === 'pending' ? (
                        <>
                          <button
                            onClick={() => approveLeave(req.id)}
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Approve</span>
                          </button>
                          <button
                            onClick={() => setRejectionModalRequest(req)}
                            className="px-3 py-1.5 bg-white hover:bg-rose-50 text-rose-700 border border-rose-300 rounded text-xs font-semibold flex items-center gap-1.5 transition-colors"
                          >
                            <X className="w-3.5 h-3.5" />
                            <span>Decline</span>
                          </button>
                        </>
                      ) : (
                        <span className="text-[11px] font-mono text-slate-400">
                          Logged on {req.appliedOn}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Leave Policy & Employee Quota Balances Overview */}
      <div className="bg-white rounded-lg border border-slate-200 p-5">
        <h2 className="text-sm font-semibold text-slate-900 mb-1">
          Company Policy Entitlements & Team Accruals
        </h2>
        <p className="text-xs text-slate-500 mb-4">
          Statutory annual vacation, paid medical allowances, and casual balances
        </p>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-2.5 px-3">Team Member</th>
                <th className="py-2.5 px-3">Department</th>
                <th className="py-2.5 px-3 text-right">Annual Leave (Used / Total)</th>
                <th className="py-2.5 px-3 text-right">Medical Sick (Used / Total)</th>
                <th className="py-2.5 px-3 text-right">Casual (Used / Total)</th>
                <th className="py-2.5 px-3 text-right">Remaining Quota</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {employees.map(emp => {
                const annualRem = emp.leaveBalances.annual.total - emp.leaveBalances.annual.used;
                const sickRem = emp.leaveBalances.sick.total - emp.leaveBalances.sick.used;
                const casualRem = emp.leaveBalances.casual.total - emp.leaveBalances.casual.used;
                const totalRem = annualRem + sickRem + casualRem;

                return (
                  <tr key={emp.id} className="hover:bg-slate-50/60">
                    <td className="py-2.5 px-3 font-medium text-slate-900">
                      {emp.name}
                    </td>
                    <td className="py-2.5 px-3 text-slate-500">
                      {emp.department}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">
                      {emp.leaveBalances.annual.used} / {emp.leaveBalances.annual.total} d
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">
                      {emp.leaveBalances.sick.used} / {emp.leaveBalances.sick.total} d
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">
                      {emp.leaveBalances.casual.used} / {emp.leaveBalances.casual.total} d
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-semibold tabular-nums text-emerald-700">
                      {totalRem} days left
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Decline Dialog Modal */}
      {rejectionModalRequest && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-md w-full p-5 space-y-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">
                Decline Leave Request
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Provide an audit note for {rejectionModalRequest.employeeName} explaining why this request cannot be approved at this time.
              </p>
            </div>

            <div>
              <label htmlFor="rejection-reason" className="block text-xs font-medium text-slate-700 mb-1">
                Reason for decline
              </label>
              <textarea
                id="rejection-reason"
                rows={3}
                placeholder="e.g. Critical release sprint overlap or team coverage shortfall..."
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-300 rounded-md focus:outline-none focus:ring-1 focus:ring-slate-900"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => {
                  setRejectionModalRequest(null);
                  setRejectReason('');
                }}
                className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmReject}
                className="px-3 py-1.5 text-xs bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded"
              >
                Confirm Decline
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
