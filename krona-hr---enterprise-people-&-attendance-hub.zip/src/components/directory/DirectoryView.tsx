import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar, 
  Star, 
  Clock, 
  ChevronRight,
  Filter,
  UserCheck
} from 'lucide-react';
import { useHR } from '../../context/HRContext';
import { Employee, DepartmentName } from '../../types/hr';

interface DirectoryViewProps {
  onOpenLeaveModal: () => void;
}

export const DirectoryView: React.FC<DirectoryViewProps> = ({ onOpenLeaveModal }) => {
  const { employees, setSelectedEmployeeForDrawer } = useHR();

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedDept, setSelectedDept] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'name' | 'attendance' | 'performance'>('name');

  const filteredEmployees = employees
    .filter(emp => {
      if (selectedDept !== 'all' && emp.department !== selectedDept) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = emp.name.toLowerCase().includes(q);
        const matchEmail = emp.email.toLowerCase().includes(q);
        const matchRole = emp.role.toLowerCase().includes(q);
        const matchId = emp.id.toLowerCase().includes(q);
        if (!matchName && !matchEmail && !matchRole && !matchId) return false;
      }
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'attendance') return b.attendanceRateMonth - a.attendanceRateMonth;
      if (sortBy === 'performance') return b.performanceScore - a.performanceScore;
      return a.name.localeCompare(b.name);
    });

  return (
    <div className="space-y-6">
      {/* Directory Filter Bar */}
      <div className="bg-white p-4 rounded-lg border border-slate-200 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          {/* Search */}
          <div className="relative w-72">
            <label htmlFor="dir-search" className="sr-only">Search employees</label>
            <Search className="w-4 h-4 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              id="dir-search"
              type="text"
              placeholder="Search by name, role, email, or ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-slate-900 focus:bg-white"
            />
          </div>

          {/* Department Filter */}
          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-slate-500 font-medium">Department:</span>
            <label htmlFor="dir-dept-filter" className="sr-only">Filter directory by department</label>
            <select
              id="dir-dept-filter"
              aria-label="Filter directory by department"
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value)}
              className="py-1 px-2.5 text-xs bg-slate-50 border border-slate-200 rounded-md text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900"
            >
              <option value="all">All Departments</option>
              <option value="Engineering">Engineering</option>
              <option value="Product">Product</option>
              <option value="Design">Design</option>
              <option value="Sales">Sales</option>
              <option value="Marketing">Marketing</option>
              <option value="Operations">Operations</option>
              <option value="People & HR">People & HR</option>
            </select>
          </div>

          {/* Sort By */}
          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-slate-500 font-medium">Sort:</span>
            <label htmlFor="dir-sort-by" className="sr-only">Sort directory list</label>
            <select
              id="dir-sort-by"
              aria-label="Sort directory list"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="py-1 px-2.5 text-xs bg-slate-50 border border-slate-200 rounded-md text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900"
            >
              <option value="name">Name (A-Z)</option>
              <option value="attendance">Monthly Attendance Rate</option>
              <option value="performance">Performance Score</option>
            </select>
          </div>
        </div>

        <div className="text-xs font-mono text-slate-500 tabular-nums">
          {filteredEmployees.length} active employee profiles
        </div>
      </div>

      {/* Directory Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filteredEmployees.map(emp => (
          <div
            key={emp.id}
            onClick={() => setSelectedEmployeeForDrawer(emp)}
            className="bg-white p-5 rounded-lg border border-slate-200 hover:border-slate-300 hover:shadow-xs transition-all cursor-pointer flex flex-col justify-between"
          >
            <div>
              {/* Header: Avatar, Name & Role */}
              <div className="flex items-start gap-3">
                {emp.avatarUrl ? (
                  <img
                    src={emp.avatarUrl}
                    alt={emp.name}
                    referrerPolicy="no-referrer"
                    className="w-12 h-12 rounded-full object-cover shrink-0 ring-1 ring-slate-200"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-800 flex items-center justify-center font-bold text-sm shrink-0 border border-slate-200">
                    {emp.name.split(' ').map(n => n[0]).join('')}
                  </div>
                )}

                <div className="min-w-0 flex-1">
                  <h3 className="font-semibold text-slate-900 text-sm truncate">
                    {emp.name}
                  </h3>
                  <p className="text-xs text-slate-600 truncate mt-0.5">
                    {emp.role}
                  </p>
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-1">
                    <span>{emp.department}</span>
                    <span>·</span>
                    <span className="font-mono text-slate-400">{emp.id}</span>
                  </div>
                </div>
              </div>

              {/* Status and Contact Meta */}
              <div className="mt-4 pt-3 border-t border-slate-100 space-y-1.5 text-xs">
                <div className="flex items-center justify-between text-slate-600">
                  <span className="text-slate-500">Today's Presence:</span>
                  <span className="font-medium capitalize text-slate-900">
                    {emp.todayStatus.replace('_', ' ')}
                  </span>
                </div>
                <div className="flex items-center justify-between text-slate-600">
                  <span className="text-slate-500">Workstation:</span>
                  <span className="text-slate-900 truncate max-w-[180px]">
                    {emp.location}
                  </span>
                </div>
                <div className="flex items-center justify-between text-slate-600">
                  <span className="text-slate-500">Email:</span>
                  <span className="text-slate-900 font-mono text-[11px] truncate max-w-[180px]">
                    {emp.email}
                  </span>
                </div>
              </div>
            </div>

            {/* Bottom Metrics: Attendance % and Rating */}
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <div>
                <span className="text-[11px] text-slate-500 block">Attendance (30d)</span>
                <span className="font-mono font-bold text-slate-900 tabular-nums">
                  {emp.attendanceRateMonth}%
                </span>
              </div>
              <div className="text-right">
                <span className="text-[11px] text-slate-500 block">Performance</span>
                <span className="font-mono font-bold text-indigo-700 tabular-nums flex items-center gap-1 justify-end">
                  <Star className="w-3 h-3 fill-indigo-600 text-indigo-600 inline" />
                  {emp.performanceScore} / 5.0
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
