import React, { useState } from 'react';
import { 
  Clock, 
  Download, 
  Plus, 
  Filter, 
  CheckCircle2, 
  AlertTriangle, 
  UserCheck, 
  Building, 
  Laptop, 
  Coffee, 
  LogOut,
  MapPin,
  Search,
  Calendar
} from 'lucide-react';
import { useHR } from '../../context/HRContext';
import { AttendanceStatus, DepartmentName } from '../../types/hr';

interface AttendanceViewProps {
  onOpenManualModal: () => void;
}

export const AttendanceView: React.FC<AttendanceViewProps> = ({ onOpenManualModal }) => {
  const { 
    employees, 
    currentUser, 
    clockIn, 
    clockOut, 
    toggleBreak, 
    attendanceLogs,
    setSelectedEmployeeForDrawer,
    currentTimeString
  } = useHR();

  const [selectedDept, setSelectedDept] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const isClockedIn = currentUser.todayStatus === 'present' || currentUser.todayStatus === 'remote';
  const isOnBreak = currentUser.todayStatus === 'on_break';

  // Filter employees
  const filteredEmployees = employees.filter(emp => {
    if (selectedDept !== 'all' && emp.department !== selectedDept) return false;
    if (selectedStatus !== 'all' && emp.todayStatus !== selectedStatus) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = emp.name.toLowerCase().includes(q);
      const matchRole = emp.role.toLowerCase().includes(q);
      const matchDept = emp.department.toLowerCase().includes(q);
      const matchId = emp.id.toLowerCase().includes(q);
      if (!matchName && !matchRole && !matchDept && !matchId) return false;
    }
    return true;
  });

  // Calculate totals
  const totalHoursToday = employees.reduce((acc, emp) => acc + emp.totalHoursToday, 0).toFixed(1);
  const presentEmployees = employees.filter(e => e.todayStatus === 'present' || e.todayStatus === 'remote' || e.todayStatus === 'on_break' || e.todayStatus === 'late');
  const avgArrival = "08:52 AM"; // Average check in

  // Export CSV
  const handleExportCSV = () => {
    const headers = ['Employee ID', 'Name', 'Department', 'Status', 'Check In', 'Check Out', 'Hours Today', 'Weekly Hours', 'Location'];
    const rows = employees.map(e => [
      e.id,
      `"${e.name}"`,
      `"${e.department}"`,
      e.todayStatus,
      e.checkInTime || 'N/A',
      e.checkOutTime || 'Active',
      e.totalHoursToday,
      e.weeklyHoursLogged,
      `"${e.location}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `krona_attendance_report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getStatusLabel = (status: AttendanceStatus) => {
    switch (status) {
      case 'present': return { text: 'Present (Office)', class: 'text-emerald-700' };
      case 'remote': return { text: 'Present (Remote)', class: 'text-indigo-700' };
      case 'on_break': return { text: 'On Rest Break', class: 'text-amber-700' };
      case 'late': return { text: 'Late Arrival', class: 'text-orange-700' };
      case 'on_leave': return { text: 'On Leave', class: 'text-blue-700' };
      case 'absent': return { text: 'Absent', class: 'text-rose-700' };
      default: return { text: status, class: 'text-slate-700' };
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: Real-time Punch Station & Shift Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Personal Real-Time Punch Clock Card */}
        <div className="bg-white p-5 rounded-lg border border-slate-200 lg:col-span-1 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                My Shift Time Tracker
              </span>
              <span className="text-xs font-mono text-slate-400">
                {currentUser.name.split(' ')[0]}'s Terminal
              </span>
            </div>

            <div className="my-4">
              <div className="text-3xl font-mono font-bold text-slate-900 tracking-tight tabular-nums">
                {currentTimeString}
              </div>
              <div className="text-xs text-slate-500 mt-1 flex items-center gap-1.5">
                <span>Shift standard: 09:00 AM – 05:00 PM</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono tabular-nums font-medium text-slate-700">
                  {currentUser.totalHoursToday > 0 ? `${currentUser.totalHoursToday} hrs logged` : 'Not clocked in'}
                </span>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100">
            <div className="flex items-center gap-2">
              {!isClockedIn ? (
                <div className="grid grid-cols-2 gap-2 w-full">
                  <button
                    onClick={() => clockIn(currentUser.id, 'Office')}
                    className="py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                  >
                    <Building className="w-3.5 h-3.5" />
                    <span>Punch In (Office)</span>
                  </button>
                  <button
                    onClick={() => clockIn(currentUser.id, 'Remote')}
                    className="py-2 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                  >
                    <Laptop className="w-3.5 h-3.5" />
                    <span>Punch In (Remote)</span>
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-2 w-full">
                  <button
                    onClick={() => toggleBreak(currentUser.id)}
                    className={`py-2 px-3 rounded text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                      isOnBreak
                        ? 'bg-amber-600 text-white hover:bg-amber-500'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200'
                    }`}
                  >
                    <Coffee className="w-3.5 h-3.5" />
                    <span>{isOnBreak ? 'Resume Work' : 'Take Break'}</span>
                  </button>
                  <button
                    onClick={() => clockOut(currentUser.id)}
                    className="py-2 px-3 bg-slate-900 hover:bg-rose-700 text-white rounded text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>End Shift</span>
                  </button>
                </div>
              )}
            </div>
            {isClockedIn && (
              <p className="text-[11px] text-slate-500 mt-2 text-center font-mono">
                Checked in at {currentUser.checkInTime}
              </p>
            )}
          </div>
        </div>

        {/* Company Shift Summary Stats */}
        <div className="bg-white p-5 rounded-lg border border-slate-200 lg:col-span-2 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <span className="text-xs font-semibold text-slate-900">
                Today's Company Work Hours & Attendance Summary
              </span>
              <span className="text-xs font-mono text-slate-500">
                {new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' })}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-4 my-4">
              <div>
                <span className="text-xs text-slate-500 block">Total Shift Hours Clocked</span>
                <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums block mt-1">
                  {totalHoursToday} hrs
                </span>
                <span className="text-[11px] text-slate-500 mt-0.5 block">
                  Across {presentEmployees.length} active team members
                </span>
              </div>
              <div>
                <span className="text-xs text-slate-500 block">Average Check-in Time</span>
                <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums block mt-1">
                  {avgArrival}
                </span>
                <span className="text-[11px] text-emerald-700 font-medium mt-0.5 block">
                  Within 15m grace window
                </span>
              </div>
              <div>
                <span className="text-xs text-slate-500 block">Overtime Recorded</span>
                <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums block mt-1">
                  0.7 hrs
                </span>
                <span className="text-[11px] text-slate-500 mt-0.5 block">
                  Engineering deployment duty
                </span>
              </div>
            </div>
          </div>

          {/* Quick Filter & Export Row */}
          <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <button
                onClick={onOpenManualModal}
                className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded text-xs font-medium flex items-center gap-1.5 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Manual Attendance Entry</span>
              </button>
            </div>
            <button
              onClick={handleExportCSV}
              className="px-3 py-1.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded text-xs font-medium flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-slate-500" />
              <span>Export CSV Ledger</span>
            </button>
          </div>
        </div>
      </div>

      {/* High-Density Real-Time Attendance Table */}
      <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
        {/* Table Filter Toolbar */}
        <div className="p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            {/* Search */}
            <div className="relative w-64">
              <label htmlFor="attendance-search" className="sr-only">Filter employees</label>
              <Search className="w-4 h-4 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="attendance-search"
                type="text"
                placeholder="Filter by name, ID, title..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-slate-900 focus:bg-white"
              />
            </div>

            {/* Department Filter */}
            <div className="flex items-center gap-1 text-xs">
              <span className="text-slate-500 font-medium">Department:</span>
              <label htmlFor="dept-filter-attendance" className="sr-only">Filter by department</label>
              <select
                id="dept-filter-attendance"
                aria-label="Filter by department"
                value={selectedDept}
                onChange={(e) => setSelectedDept(e.target.value)}
                className="py-1 px-2.5 text-xs bg-slate-50 border border-slate-200 rounded-md text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900"
              >
                <option value="all">All Departments</option>
                <option value="Engineering">Engineering</option>
                <option value="Product">Product</option>
                <option value="Design">Design</option>
                <option value="Marketing">Marketing</option>
                <option value="Sales">Sales</option>
                <option value="Operations">Operations</option>
                <option value="People & HR">People & HR</option>
              </select>
            </div>

            {/* Status Filter */}
            <div className="flex items-center gap-1 text-xs">
              <span className="text-slate-500 font-medium">Status:</span>
              <label htmlFor="status-filter-attendance" className="sr-only">Filter by attendance status</label>
              <select
                id="status-filter-attendance"
                aria-label="Filter by attendance status"
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="py-1 px-2.5 text-xs bg-slate-50 border border-slate-200 rounded-md text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900"
              >
                <option value="all">All Statuses</option>
                <option value="present">Present (Office)</option>
                <option value="remote">Present (Remote)</option>
                <option value="on_break">On Break</option>
                <option value="late">Late Arrival</option>
                <option value="on_leave">On Leave</option>
                <option value="absent">Absent</option>
              </select>
            </div>
          </div>

          <div className="text-xs font-mono text-slate-500 tabular-nums">
            Showing {filteredEmployees.length} of {employees.length} records
          </div>
        </div>

        {/* Dense Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/75 border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-2.5 px-4">Employee</th>
                <th className="py-2.5 px-4">Department & Role</th>
                <th className="py-2.5 px-4">Today Status</th>
                <th className="py-2.5 px-4">Check-In</th>
                <th className="py-2.5 px-4">Check-Out</th>
                <th className="py-2.5 px-4 text-right">Hours Logged</th>
                <th className="py-2.5 px-4">Work Location</th>
                <th className="py-2.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {filteredEmployees.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    No attendance records match your filter criteria.
                  </td>
                </tr>
              ) : (
                filteredEmployees.map(emp => {
                  const statusInfo = getStatusLabel(emp.todayStatus);
                  return (
                    <tr 
                      key={emp.id} 
                      className="hover:bg-slate-50/80 transition-colors group cursor-pointer"
                      onClick={() => setSelectedEmployeeForDrawer(emp)}
                    >
                      {/* Name & ID */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2.5">
                          {emp.avatarUrl ? (
                            <img
                              src={emp.avatarUrl}
                              alt={emp.name}
                              referrerPolicy="no-referrer"
                              className="w-7 h-7 rounded-full object-cover shrink-0 ring-1 ring-slate-200"
                            />
                          ) : (
                            <div className="w-7 h-7 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center font-medium text-[10px] shrink-0">
                              {emp.name.split(' ').map(n => n[0]).join('')}
                            </div>
                          )}
                          <div>
                            <span className="font-semibold text-slate-900 group-hover:text-indigo-600 transition-colors block">
                              {emp.name}
                            </span>
                            <span className="text-[11px] font-mono text-slate-400 block">
                              {emp.id}
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Department & Role */}
                      <td className="py-3 px-4">
                        <span className="text-slate-800 font-medium block">{emp.role}</span>
                        <span className="text-slate-500 text-[11px] block">{emp.department}</span>
                      </td>

                      {/* Status */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5">
                          <span className={`w-2 h-2 rounded-full shrink-0 ${
                            emp.todayStatus === 'present' ? 'bg-emerald-500' :
                            emp.todayStatus === 'remote' ? 'bg-indigo-500' :
                            emp.todayStatus === 'on_break' ? 'bg-amber-500' :
                            emp.todayStatus === 'late' ? 'bg-orange-500' :
                            emp.todayStatus === 'on_leave' ? 'bg-blue-500' : 'bg-rose-500'
                          }`} />
                          <span className={`font-medium ${statusInfo.class}`}>
                            {statusInfo.text}
                          </span>
                        </div>
                      </td>

                      {/* Check-In */}
                      <td className="py-3 px-4 font-mono tabular-nums text-slate-700">
                        {emp.checkInTime || '—'}
                      </td>

                      {/* Check-Out */}
                      <td className="py-3 px-4 font-mono tabular-nums text-slate-700">
                        {emp.checkOutTime || (emp.checkInTime ? 'Active' : '—')}
                      </td>

                      {/* Hours */}
                      <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-slate-900">
                        {emp.totalHoursToday.toFixed(1)} h
                      </td>

                      {/* Location */}
                      <td className="py-3 px-4 text-slate-600 truncate max-w-xs">
                        {emp.location}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => setSelectedEmployeeForDrawer(emp)}
                          className="px-2.5 py-1 text-slate-600 hover:text-indigo-600 hover:bg-slate-100 rounded text-xs font-medium transition-colors"
                        >
                          Dossier
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
